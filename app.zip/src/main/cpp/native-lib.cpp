#include <jni.h>
#include <vector>
#include <cmath>    // For std::sqrt, std::floor, std::round, std::abs (double)
#include <cstdlib>  // For std::abs (int), rand, RAND_MAX
#include <android/bitmap.h>
#include <string>
#include <numeric>   // For std::iota
#include <algorithm> // For std::sort, std::swap
#include <stdexcept>  // For std::out_of_range, std::invalid_argument (potentially caught by catch(...))
                     // std::bad_alloc (from vector::reserve) is in <new>, also caught by catch(...)
#include <cstdio>    // For snprintf

// --- 日志宏定义 (空操作) ---
#define LOGI(...)
#define LOGE(...)
#define LOGD(...)
#define LOGW(...)

// ========================================================================
// MD5 实现 (hexdigest modified)
// ========================================================================
class MD5 {
public:
    typedef unsigned int size_type;
    MD5(); MD5(const std::string& text);
    void update(const unsigned char *buf, size_type length); void update(const char *buf, size_type length);
    MD5& finalize(); std::string hexdigest() const;
private:
    void init(); typedef unsigned char uint1; typedef unsigned int uint4; enum {blocksize = 64};
    void transform(const uint1 block[blocksize]);
    static void decode(uint4 o[], const uint1 i[], size_type l); static void encode(uint1 o[], const uint4 i[], size_type l);
    bool finalized; uint1 buffer[blocksize]; uint4 count[2]; uint4 state[4]; uint1 digest[16];
    static inline uint4 F(uint4 x,uint4 y,uint4 z); static inline uint4 G(uint4 x,uint4 y,uint4 z);
    static inline uint4 H(uint4 x,uint4 y,uint4 z); static inline uint4 I(uint4 x,uint4 y,uint4 z);
    static inline uint4 rotate_left(uint4 x, int n);
    static inline void FF(uint4 &a,uint4 b,uint4 c,uint4 d,uint4 x,uint4 s,uint4 t);
    static inline void GG(uint4 &a,uint4 b,uint4 c,uint4 d,uint4 x,uint4 s,uint4 t);
    static inline void HH(uint4 &a,uint4 b,uint4 c,uint4 d,uint4 x,uint4 s,uint4 t);
    static inline void II(uint4 &a,uint4 b,uint4 c,uint4 d,uint4 x,uint4 s,uint4 t);
};
std::string md5(const std::string& str);
#define S11 7
#define S12 12
#define S13 17
#define S14 22
#define S21 5
#define S22 9
#define S23 14
#define S24 20
#define S31 4
#define S32 11
#define S33 16
#define S34 23
#define S41 6
#define S42 10
#define S43 15
#define S44 21
inline MD5::uint4 MD5::F(uint4 x,uint4 y,uint4 z){return(x&y)|(~x&z);}
inline MD5::uint4 MD5::G(uint4 x,uint4 y,uint4 z){return(x&z)|(y&~z);}
inline MD5::uint4 MD5::H(uint4 x,uint4 y,uint4 z){return x^y^z;}
inline MD5::uint4 MD5::I(uint4 x,uint4 y,uint4 z){return y^(x|~z);}
inline MD5::uint4 MD5::rotate_left(uint4 x,int n){return(x<<n)|(x>>(32-n));}
inline void MD5::FF(uint4&a,uint4 b,uint4 c,uint4 d,uint4 x,uint4 s,uint4 t){a=rotate_left(a+F(b,c,d)+x+t,s)+b;}
inline void MD5::GG(uint4&a,uint4 b,uint4 c,uint4 d,uint4 x,uint4 s,uint4 t){a=rotate_left(a+G(b,c,d)+x+t,s)+b;}
inline void MD5::HH(uint4&a,uint4 b,uint4 c,uint4 d,uint4 x,uint4 s,uint4 t){a=rotate_left(a+H(b,c,d)+x+t,s)+b;}
inline void MD5::II(uint4&a,uint4 b,uint4 c,uint4 d,uint4 x,uint4 s,uint4 t){a=rotate_left(a+I(b,c,d)+x+t,s)+b;}
MD5::MD5(){init();}
MD5::MD5(const std::string&text){init();update(text.c_str(),text.length());finalize();}
void MD5::init(){finalized=false;count[0]=0;count[1]=0;state[0]=0x67452301;state[1]=0xefcdab89;state[2]=0x98badcfe;state[3]=0x10325476;}
void MD5::decode(uint4 o[],const uint1 i[],size_type l){for(unsigned int k=0,j=0;j<l;k++,j+=4)o[k]=((uint4)i[j])|(((uint4)i[j+1])<<8)|(((uint4)i[j+2])<<16)|(((uint4)i[j+3])<<24);}
void MD5::encode(uint1 o[],const uint4 i[],size_type l){for(unsigned int k=0,j=0;j<l;k++,j+=4){o[j]=i[k]&0xff;o[j+1]=(i[k]>>8)&0xff;o[j+2]=(i[k]>>16)&0xff;o[j+3]=(i[k]>>24)&0xff;}}
void MD5::transform(const uint1 b[blocksize]){uint4 cur_a=state[0],cur_b=state[1],cur_c=state[2],cur_d=state[3],x_arr[16];decode(x_arr,b,blocksize);
FF(cur_a,cur_b,cur_c,cur_d,x_arr[0],S11,0xd76aa478);FF(cur_d,cur_a,cur_b,cur_c,x_arr[1],S12,0xe8c7b756);FF(cur_c,cur_d,cur_a,cur_b,x_arr[2],S13,0x242070db);FF(cur_b,cur_c,cur_d,cur_a,x_arr[3],S14,0xc1bdceee);
FF(cur_a,cur_b,cur_c,cur_d,x_arr[4],S11,0xf57c0faf);FF(cur_d,cur_a,cur_b,cur_c,x_arr[5],S12,0x4787c62a);FF(cur_c,cur_d,cur_a,cur_b,x_arr[6],S13,0xa8304613);FF(cur_b,cur_c,cur_d,cur_a,x_arr[7],S14,0xfd469501);
FF(cur_a,cur_b,cur_c,cur_d,x_arr[8],S11,0x698098d8);FF(cur_d,cur_a,cur_b,cur_c,x_arr[9],S12,0x8b44f7af);FF(cur_c,cur_d,cur_a,cur_b,x_arr[10],S13,0xffff5bb1);FF(cur_b,cur_c,cur_d,cur_a,x_arr[11],S14,0x895cd7be);
FF(cur_a,cur_b,cur_c,cur_d,x_arr[12],S11,0x6b901122);FF(cur_d,cur_a,cur_b,cur_c,x_arr[13],S12,0xfd987193);FF(cur_c,cur_d,cur_a,cur_b,x_arr[14],S13,0xa679438e);FF(cur_b,cur_c,cur_d,cur_a,x_arr[15],S14,0x49b40821);
GG(cur_a,cur_b,cur_c,cur_d,x_arr[1],S21,0xf61e2562);GG(cur_d,cur_a,cur_b,cur_c,x_arr[6],S22,0xc040b340);GG(cur_c,cur_d,cur_a,cur_b,x_arr[11],S23,0x265e5a51);GG(cur_b,cur_c,cur_d,cur_a,x_arr[0],S24,0xe9b6c7aa);
GG(cur_a,cur_b,cur_c,cur_d,x_arr[5],S21,0xd62f105d);GG(cur_d,cur_a,cur_b,cur_c,x_arr[10],S22,0x2441453);GG(cur_c,cur_d,cur_a,cur_b,x_arr[15],S23,0xd8a1e681);GG(cur_b,cur_c,cur_d,cur_a,x_arr[4],S24,0xe7d3fbc8);
GG(cur_a,cur_b,cur_c,cur_d,x_arr[9],S21,0x21e1cde6);GG(cur_d,cur_a,cur_b,cur_c,x_arr[14],S22,0xc33707d6);GG(cur_c,cur_d,cur_a,cur_b,x_arr[3],S23,0xf4d50d87);GG(cur_b,cur_c,cur_d,cur_a,x_arr[8],S24,0x455a14ed);
GG(cur_a,cur_b,cur_c,cur_d,x_arr[13],S21,0xa9e3e905);GG(cur_d,cur_a,cur_b,cur_c,x_arr[2],S22,0xfcefa3f8);GG(cur_c,cur_d,cur_a,cur_b,x_arr[7],S23,0x676f02d9);GG(cur_b,cur_c,cur_d,cur_a,x_arr[12],S24,0x8d2a4c8a);
HH(cur_a,cur_b,cur_c,cur_d,x_arr[5],S31,0xfffa3942);HH(cur_d,cur_a,cur_b,cur_c,x_arr[8],S32,0x8771f681);HH(cur_c,cur_d,cur_a,cur_b,x_arr[11],S33,0x6d9d6122);HH(cur_b,cur_c,cur_d,cur_a,x_arr[14],S34,0xfde5380c);
HH(cur_a,cur_b,cur_c,cur_d,x_arr[1],S31,0xa4beea44);HH(cur_d,cur_a,cur_b,cur_c,x_arr[4],S32,0x4bdecfa9);HH(cur_c,cur_d,cur_a,cur_b,x_arr[7],S33,0xf6bb4b60);HH(cur_b,cur_c,cur_d,cur_a,x_arr[10],S34,0xbebfbc70);
HH(cur_a,cur_b,cur_c,cur_d,x_arr[13],S31,0x289b7ec6);HH(cur_d,cur_a,cur_b,cur_c,x_arr[0],S32,0xeaa127fa);HH(cur_c,cur_d,cur_a,cur_b,x_arr[3],S33,0xd4ef3085);HH(cur_b,cur_c,cur_d,cur_a,x_arr[6],S34,0x4881d05);
HH(cur_a,cur_b,cur_c,cur_d,x_arr[9],S31,0xd9d4d039);HH(cur_d,cur_a,cur_b,cur_c,x_arr[12],S32,0xe6db99e5);HH(cur_c,cur_d,cur_a,cur_b,x_arr[15],S33,0x1fa27cf8);HH(cur_b,cur_c,cur_d,cur_a,x_arr[2],S34,0xc4ac5665);
II(cur_a,cur_b,cur_c,cur_d,x_arr[0],S41,0xf4292244);II(cur_d,cur_a,cur_b,cur_c,x_arr[7],S42,0x432aff97);II(cur_c,cur_d,cur_a,cur_b,x_arr[14],S43,0xab9423a7);II(cur_b,cur_c,cur_d,cur_a,x_arr[5],S44,0xfc93a039);
II(cur_a,cur_b,cur_c,cur_d,x_arr[12],S41,0x655b59c3);II(cur_d,cur_a,cur_b,cur_c,x_arr[3],S42,0x8f0ccc92);II(cur_c,cur_d,cur_a,cur_b,x_arr[10],S43,0xffeff47d);II(cur_b,cur_c,cur_d,cur_a,x_arr[1],S44,0x85845dd1);
II(cur_a,cur_b,cur_c,cur_d,x_arr[8],S41,0x6fa87e4f);II(cur_d,cur_a,cur_b,cur_c,x_arr[15],S42,0xfe2ce6e0);II(cur_c,cur_d,cur_a,cur_b,x_arr[6],S43,0xa3014314);II(cur_b,cur_c,cur_d,cur_a,x_arr[13],S44,0x4e0811a1);
II(cur_a,cur_b,cur_c,cur_d,x_arr[4],S41,0xf7537e82);II(cur_d,cur_a,cur_b,cur_c,x_arr[11],S42,0xbd3af235);II(cur_c,cur_d,cur_a,cur_b,x_arr[2],S43,0x2ad7d2bb);II(cur_b,cur_c,cur_d,cur_a,x_arr[9],S44,0xeb86d391);
state[0]+=cur_a;state[1]+=cur_b;state[2]+=cur_c;state[3]+=cur_d; for(int i=0;i<16;i++)x_arr[i]=0;}
void MD5::update(const unsigned char i_arr[],size_type l){size_type idx=count[0]/8%blocksize;if((count[0]+=(l<<3))<(l<<3))count[1]++;count[1]+=(l>>29);size_type fp=64-idx;size_type k_idx;if(l>=fp){for(k_idx=0;k_idx<fp;k_idx++)buffer[k_idx+idx]=i_arr[k_idx];transform(buffer);for(k_idx=fp;k_idx+blocksize<=l;k_idx+=blocksize)transform(&i_arr[k_idx]);idx=0;}else k_idx=0;for(size_type j_idx=0;j_idx<l-k_idx;j_idx++)buffer[idx+j_idx]=i_arr[k_idx+j_idx];}
void MD5::update(const char i_arr[],size_type l){update((const unsigned char*)i_arr,l);}
MD5&MD5::finalize(){static unsigned char p_arr[64]={0x80,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};if(!finalized){unsigned char b_arr[8];encode(b_arr,count,8);size_type idx=count[0]/8%64;size_type pl=(idx<56)?(56-idx):(120-idx);update(p_arr,pl);update(b_arr,8);encode(digest,state,16);finalized=true;}return *this;}

std::string MD5::hexdigest() const {
    if (!finalized) return "";
    char hex_buf[33]; // 16 bytes * 2 chars/byte + 1 null terminator
    for (int i_idx = 0; i_idx < 16; ++i_idx) {
        // Using snprintf which is generally smaller than ostringstream for this task.
        // Ensure digest[i_idx] is treated as unsigned char for %02x.
        snprintf(hex_buf + i_idx * 2, 3, "%02x", static_cast<unsigned char>(digest[i_idx]));
    }
    // hex_buf[32] is implicitly null-terminated by the last snprintf call if all goes well.
    // To be absolutely safe, one could add hex_buf[32] = '\0'; but snprintf with size 3 per pair should handle it.
    return std::string(hex_buf);
}
std::string md5(const std::string&s_str){MD5 m_obj=MD5(s_str);return m_obj.hexdigest();}

struct Point{int x;int y;}; template<typename T>int sgn(T v){return(T(0)<v)-(v<T(0));}
void generate2d(int x_coord,int y_coord,int ax_val,int ay_val,int bx_val,int by_val,std::vector<Point>&coords_vec){
    int w_val=std::abs(ax_val+ay_val);int h_val=std::abs(bx_val+by_val);if(w_val==0||h_val==0)return;int dax_v=sgn(ax_val),day_v=sgn(ay_val),dbx_v=sgn(bx_val),dby_v=sgn(by_val);
    if(h_val==1){for(int i_idx=0;i_idx<w_val;++i_idx){coords_vec.push_back({x_coord,y_coord});x_coord+=dax_v;y_coord+=day_v;}return;}if(w_val==1){for(int i_idx=0;i_idx<h_val;++i_idx){coords_vec.push_back({x_coord,y_coord});x_coord+=dbx_v;y_coord+=dby_v;}return;}
    int ax2_v=static_cast<int>(std::floor((double)ax_val/2.0));int ay2_v=static_cast<int>(std::floor((double)ay_val/2.0));
    int bx2_v=static_cast<int>(std::floor((double)bx_val/2.0));int by2_v=static_cast<int>(std::floor((double)by_val/2.0));
    int w2_v=std::abs(ax2_v+ay2_v);int h2_v=std::abs(bx2_v+by2_v);
    if(2*w_val>3*h_val){if((w2_v%2!=0)&&(w_val>2)){ax2_v+=dax_v;ay2_v+=day_v;}generate2d(x_coord,y_coord,ax2_v,ay2_v,bx_val,by_val,coords_vec);generate2d(x_coord+ax2_v,y_coord+ay2_v,ax_val-ax2_v,ay_val-ay2_v,bx_val,by_val,coords_vec);}
    else{if((h2_v%2!=0)&&(h_val>2)){bx2_v+=dbx_v;by2_v+=dby_v;}generate2d(x_coord,y_coord,bx2_v,by2_v,ax2_v,ay2_v,coords_vec);generate2d(x_coord+bx2_v,y_coord+by2_v,ax_val,ay_val,bx_val-bx2_v,by_val-by2_v,coords_vec);generate2d(x_coord+(ax_val-dax_v)+(bx2_v-dbx_v),y_coord+(ay_val-day_v)+(by2_v-dby_v),-bx2_v,-by2_v,-(ax_val-ax2_v),-(ay_val-ay2_v),coords_vec);}}
std::vector<Point>gilbert2d(int w_param,int h_param){std::vector<Point>coords_res;if(w_param<=0||h_param<=0)return coords_res;size_t es_val=(size_t)w_param*h_param;try{coords_res.reserve(es_val);}catch(...){}
if(w_param>=h_param)generate2d(0,0,w_param,0,0,h_param,coords_res);else generate2d(0,0,0,h_param,w_param,0,coords_res);if(coords_res.size()!=es_val){if(coords_res.size()>es_val)coords_res.resize(es_val);}return coords_res;}

extern"C" JNIEXPORT jstring JNICALL Java_io_github_fqt_MainActivity_getMenuItemAboutText(JNIEnv*e,jobject){return e->NewStringUTF("帮助");}
extern"C" JNIEXPORT jstring JNICALL Java_io_github_fqt_MainActivity_getDialogTitle(JNIEnv*e,jobject){return e->NewStringUTF("\u5173\u4e8e");}
extern"C" JNIEXPORT jstring JNICALL Java_io_github_fqt_MainActivity_getDialogMessage(JNIEnv*e,jobject){return e->NewStringUTF("本软件免费！\n\n番茄图混淆 V1.5 \n改动：新增底部「全部」按钮对应上方同色按钮的全部操作。\n空间曲线混淆使用jpg为保存格式以大幅减小图片大小，其他混淆png格式不变。\n\n使用帮助：\n0.大图和缩略图皆可长按。\n1.  当有多张图片时可左右滑动大图或点击底部缩略图以切换图片\n 2. 上传图片：点击「添加图片」按钮上传图片，可多选。后续如果增加图片可点缩略图列表右边的+按钮，也可多选图片。\n3. 混淆/解混淆：点击对应按钮\n4. 操作全部：点击带“全部”字样的按钮。\n5. 保存图片：点击「存本图」按钮保存当前图片，保存全部图片就点「存本图」下方同色的「全部」按钮\n\n\u8d34\u5427\uff1a\u7136\u800c\u4ed6 \n\u7b97\u6cd5\u6765\u81ea\u4e8e\u7f51\u7edc\u4ec5\u9650\u4e8e\u6280\u672f\u5b66\u4e60\u4f7f\u7528");}
extern"C" JNIEXPORT jstring JNICALL Java_io_github_fqt_MainActivity_getDialogButtonText(JNIEnv*e,jobject){return e->NewStringUTF("\u786e\u5b9a");}

namespace { // Anonymous namespace for helper function
    // Custom hex string to unsigned long long parser.
    // Assumes input is a short hex string (e.g., 7 chars from MD5).
    // Does not do full ULL overflow checking as 7 hex chars won't overflow ULL.
    bool hex_str_to_ull(const std::string& hex_str, unsigned long long& out_val) {
        out_val = 0;
        if (hex_str.empty() || hex_str.length() > 16) { // Max 16 hex chars for ULL
            return false;
        }
        for (char c : hex_str) {
            out_val <<= 4;
            if (c >= '0' && c <= '9') {
                out_val += (c - '0');
            } else if (c >= 'a' && c <= 'f') {
                out_val += (c - 'a' + 10);
            } else if (c >= 'A' && c <= 'F') {
                out_val += (c - 'A' + 10);
            } else {
                return false; // Invalid hex character
            }
        }
        return true;
    }
} // end anonymous namespace

std::vector<size_t> generatePermutation_JS_MD5_compatible(size_t arr_len, const std::string& key_str) {
    if (arr_len == 0) return {};
    std::vector<size_t> arr_res(arr_len);
    std::iota(arr_res.begin(), arr_res.end(), 0);

    for (size_t i_loop = arr_len - 1; i_loop > 0; --i_loop) {
        std::string md5_input = key_str + std::to_string(i_loop);
        std::string hash_val = md5(md5_input);
        unsigned long long val_h;

        if (hash_val.length() < 7) {
            unsigned int seed = 0; for(char ch : md5_input) seed = seed * 31 + ch; // Simple hash for seed
            srand(seed);
            std::swap(arr_res[rand() % (i_loop + 1)], arr_res[i_loop]);
            continue;
        }
        std::string sub_h = hash_val.substr(0, 7);

        if (!hex_str_to_ull(sub_h, val_h)) { // Use custom parser
            // Fallback if parsing failed (e.g., md5 returned non-hex, or our parser has a bug for an edge case)
            unsigned int seed = 0; for(char ch : md5_input) seed = seed * 31 + ch; // Simple hash for seed
            srand(seed);
            std::swap(arr_res[rand() % (i_loop + 1)], arr_res[i_loop]);
            continue;
        }
        size_t rand_i = static_cast<size_t>(val_h % (i_loop + 1));
        std::swap(arr_res[rand_i], arr_res[i_loop]);
    }
    return arr_res;
}
/*
std::vector<size_t> generateLogisticPermutation(size_t s_val,double x0_val,double*xo_ptr=0){
    if(s_val==0)return{};if(x0_val<=0||x0_val>=1)return{};std::vector<std::pair<double,size_t>>m_vec(s_val);double cur_x=x0_val;const double r_const=3.9999999;
    if(s_val>0) m_vec[0]={cur_x,0};
    for(size_t i_idx=1;i_idx<s_val;++i_idx){cur_x=r_const*cur_x*(1.0-cur_x);m_vec[i_idx]={cur_x,i_idx};}
    if(xo_ptr)*xo_ptr=cur_x;
    std::sort(m_vec.begin(),m_vec.end(),[](const std::pair<double,size_t>&a_pair,const std::pair<double,size_t>&b_pair){return a_pair.first<b_pair.first;});
    std::vector<size_t>p_res(s_val);for(size_t i_idx=0;i_idx<s_val;++i_idx)p_res[i_idx]=m_vec[i_idx].second;return p_res;}
*/

// ... (other code) ...

std::vector<size_t> generateLogisticPermutation(size_t s_val, double x0_val, double* xo_ptr = 0) {
    if (s_val == 0) return {};
    // Ensure x0_val is strictly within (0, 1) for the current run
    if (x0_val <= 0.0 || x0_val >= 1.0) return {};

    std::vector<std::pair<double, size_t>> m_vec(s_val);
    double cur_x = x0_val;
    const double r_const = 3.9999999; // Logistic map parameter

    if (s_val > 0) m_vec[0] = {cur_x, 0};

    for (size_t i_idx = 1; i_idx < s_val; ++i_idx) {
        cur_x = r_const * cur_x * (1.0 - cur_x);
        m_vec[i_idx] = {cur_x, i_idx};
    }

    if (xo_ptr) {
        double next_x0 = cur_x;
        // Clamp next_x0 to prevent it from becoming exactly 0 or 1, or out of bounds due to precision.
        // These epsilons should be small enough not to significantly bias the sequence
        // but large enough to keep it within the valid (0,1) range for the next iteration.
        const double epsilon = 1e-15; // A very small number
        if (next_x0 <= 0.0) {
            next_x0 = epsilon;
        } else if (next_x0 >= 1.0) {
            next_x0 = 1.0 - epsilon;
        }
        *xo_ptr = next_x0;
    }

    std::sort(m_vec.begin(), m_vec.end(), [](const std::pair<double, size_t>& a_pair, const std::pair<double, size_t>& b_pair) {
        return a_pair.first < b_pair.first;
    });

    std::vector<size_t> p_res(s_val);
    for (size_t i_idx = 0; i_idx < s_val; ++i_idx) p_res[i_idx] = m_vec[i_idx].second;
    return p_res;
}

// ... (other functions) ...

bool processPE2(uint32_t*in_buf,uint32_t*out_buf,int w_val,int h_val,unsigned int ppr_val,double kx0_val,bool enc_mode){
    if(w_val==0||h_val==0)return true;
    if(ppr_val == 0 && (w_val > 0 || h_val > 0)) return false; // Should not happen if w_val > 0 from getInfo

    size_t buf_s_elements=(size_t)h_val*w_val;
    std::vector<uint32_t>tmp_b(buf_s_elements); // Compact temporary buffer
    uint32_t*pt_buf=tmp_b.data();
    double cx_log; // Current x0 for logistic map

    // Max index for strided in_buf/out_buf (number of uint32_t elements)
    size_t max_strided_buffer_idx_plus_1 = (size_t)h_val * ppr_val;


    if(enc_mode){
        // --- Encryption: Pass 1 (Row-wise permutation, in_buf -> tmp_b) ---
        cx_log=kx0_val;
        for(int r_lp=0;r_lp<h_val;++r_lp){
            double ex_log; // Next x0
            std::vector<size_t>p_arr=generateLogisticPermutation(w_val,cx_log,&ex_log);
            if(w_val>0&&(p_arr.empty()||p_arr.size()!=static_cast<size_t>(w_val)))return false;
            cx_log=ex_log;

            for(int ct_val=0;ct_val<w_val;++ct_val){
                size_t sc_val = (w_val > 0 ? p_arr[ct_val] : 0); // Source column
                if(w_val > 0 && sc_val >= static_cast<size_t>(w_val)) return false; // Should not happen if p_arr is correct

                size_t ti_idx_elem = (size_t)r_lp * w_val + ct_val;         // Index for compact tmp_b
                size_t si_idx_buf  = (size_t)r_lp * ppr_val + sc_val;       // Index for strided in_buf

                if (ti_idx_elem >= tmp_b.size() || si_idx_buf >= max_strided_buffer_idx_plus_1) return false;
                pt_buf[ti_idx_elem] = in_buf[si_idx_buf];
            }
        }

        // --- Encryption: Pass 2 (Column-wise permutation, tmp_b -> out_buf) ---
        cx_log=kx0_val; // Re-initialize for column pass (consistent with decryption)
        for(int c_lp=0;c_lp<w_val;++c_lp){
            double ex_log;
            std::vector<size_t>p_arr=generateLogisticPermutation(h_val,cx_log,&ex_log);
            if(h_val>0&&(p_arr.empty()||p_arr.size()!=static_cast<size_t>(h_val)))return false;
            cx_log=ex_log;

            for(int rt_val=0;rt_val<h_val;++rt_val){
                size_t sr_val = (h_val > 0 ? p_arr[rt_val] : 0); // Source row
                if(h_val > 0 && sr_val >= static_cast<size_t>(h_val)) return false;

                size_t ti_idx_buf  = (size_t)rt_val * ppr_val + c_lp;       // Index for strided out_buf
                size_t si_idx_elem = sr_val * w_val + (size_t)c_lp;         // Index for compact tmp_b

                if (ti_idx_buf >= max_strided_buffer_idx_plus_1 || si_idx_elem >= tmp_b.size()) return false;
                out_buf[ti_idx_buf] = pt_buf[si_idx_elem];
            }
        }
    } else { // Decryption
        // --- Decryption: Pass 1 (Reverse Column-wise permutation, in_buf -> tmp_b) ---
        // This reverses Encryption Pass 2
        cx_log=kx0_val;
        for(int c_lp=0;c_lp<w_val;++c_lp){
            double ex_log;
            std::vector<size_t>p_arr=generateLogisticPermutation(h_val,cx_log,&ex_log);
            if(h_val>0&&(p_arr.empty()||p_arr.size()!=static_cast<size_t>(h_val)))return false;
            cx_log=ex_log;

            for(int re_val=0;re_val<h_val;++re_val){ // Target row in tmp_b for original data
                size_t Or_val = (h_val > 0 ? p_arr[re_val] : 0); // Original source row for this encrypted element
                if(h_val > 0 && Or_val >= static_cast<size_t>(h_val)) return false;

                // ei_idx_buf: where the data currently is in in_buf (encrypted data)
                // Oi_idx_elem: where the data *should go* in tmp_b (original position after this pass)
                size_t ei_idx_buf  = (size_t)re_val * ppr_val + c_lp;    // Index for strided in_buf
                size_t Oi_idx_elem = Or_val * w_val + (size_t)c_lp;      // Index for compact tmp_b

                if (ei_idx_buf >= max_strided_buffer_idx_plus_1 || Oi_idx_elem >= tmp_b.size()) return false;
                pt_buf[Oi_idx_elem] = in_buf[ei_idx_buf];
            }
        }

        // --- Decryption: Pass 2 (Reverse Row-wise permutation, tmp_b -> out_buf) ---
        // This reverses Encryption Pass 1
        cx_log=kx0_val;
        for(int r_lp=0;r_lp<h_val;++r_lp){
            double ex_log;
            std::vector<size_t>p_arr=generateLogisticPermutation(w_val,cx_log,&ex_log);
            if(w_val>0&&(p_arr.empty()||p_arr.size()!=static_cast<size_t>(w_val)))return false;
            cx_log=ex_log;

            for(int ce_val=0;ce_val<w_val;++ce_val){ // Target column in out_buf for original data
                size_t Oc_val = (w_val > 0 ? p_arr[ce_val] : 0); // Original source column
                if(w_val > 0 && Oc_val >= static_cast<size_t>(w_val)) return false;

                // ei_idx_elem: where data currently is in tmp_b
                // Oi_idx_buf: where data *should go* in out_buf (final original position)
                size_t ei_idx_elem = (size_t)r_lp * w_val + ce_val;      // Index for compact tmp_b
                size_t Oi_idx_buf  = (size_t)r_lp * ppr_val + Oc_val;    // Index for strided out_buf

                if (ei_idx_elem >= tmp_b.size() || Oi_idx_buf >= max_strided_buffer_idx_plus_1) return false;
                out_buf[Oi_idx_buf] = pt_buf[ei_idx_elem];
            }
        }
    }
    return true;
}

// ... (rest of the JNI functions and processImageCommon) ...

template<typename ProcType>bool processPixelsGeneric(uint32_t*in_buf,uint32_t*out_buf,int img_w,int img_h,unsigned int row_pix,ProcType proc_func){
    size_t max_idx_val=(size_t)img_h*row_pix;for(int y_coord=0;y_coord<img_h;++y_coord){for(int x_coord=0;x_coord<img_w;++x_coord){try{proc_func(x_coord,y_coord,img_w,img_h,row_pix,max_idx_val,in_buf,out_buf);}catch(...){return false;}}}return true;}

bool processGilbert(uint32_t*in_buf,uint32_t*out_buf,int img_w,int img_h,unsigned int row_pix,bool enc_mode){
    long long num_pix_ll=(long long)img_w*img_h;if(num_pix_ll==0)return true;size_t num_pix_val=(size_t)num_pix_ll;std::vector<Point>curve_pts=gilbert2d(img_w,img_h);if(curve_pts.empty())return false;
    if(curve_pts.size()<num_pix_val)num_pix_val=curve_pts.size();else if(curve_pts.size()>num_pix_val){}double gr_val=(std::sqrt(5.0)-1.0)/2.0;long long offset_val_ll=(long long)std::round(gr_val*(double)num_pix_ll);
    if(num_pix_ll>0)offset_val_ll%=num_pix_ll;if(offset_val_ll<0)offset_val_ll+=num_pix_ll;size_t offset_val=(size_t)offset_val_ll;size_t max_buf_idx_val=(size_t)img_h*row_pix;
    for(size_t i_val=0;i_val<num_pix_val;++i_val){size_t cur_i=i_val;size_t shift_i=(cur_i+offset_val);if(num_pix_val>0)shift_i%=num_pix_val;if(cur_i>=curve_pts.size()||shift_i>=curve_pts.size())continue;
    const Point&pos1_pt=curve_pts[cur_i];const Point&pos2_pt=curve_pts[shift_i];if(pos1_pt.x<0||pos1_pt.x>=img_w||pos1_pt.y<0||pos1_pt.y>=img_h||pos2_pt.x<0||pos2_pt.x>=img_w||pos2_pt.y<0||pos2_pt.y>=img_h)continue;
    size_t idx1_val=pos1_pt.y*row_pix+pos1_pt.x;size_t idx2_val=pos2_pt.y*row_pix+pos2_pt.x;if(idx1_val>=max_buf_idx_val||idx2_val>=max_buf_idx_val)continue;if(enc_mode)out_buf[idx2_val]=in_buf[idx1_val];else out_buf[idx1_val]=in_buf[idx2_val];}return true;}

bool processBlockScramble(uint32_t*in_buf,uint32_t*out_buf,int w_o,int h_o,unsigned int ppr_val,const std::string&key_val,int sx_js,int sy_js,bool enc_mode){
    if(sx_js<=0||sy_js<=0)return false;int w1=w_o,h1=h_o;int wp_js=w1;while(wp_js%sx_js>0){wp_js++;}int hp_js=h1;while(hp_js%sy_js>0){hp_js++;}
    if(wp_js==0||hp_js==0)return true;double ssx_val=(double)wp_js/sx_js;double ssy_val=(double)hp_js/sy_js;if(ssx_val<1.0||ssy_val<1.0)return false;
    std::vector<size_t>xl_vec=generatePermutation_JS_MD5_compatible(sx_js,key_val);std::vector<size_t>yl_vec=generatePermutation_JS_MD5_compatible(sy_js,key_val);
    if((sx_js>0&&xl_vec.size()!=static_cast<size_t>(sx_js))||(sy_js>0&&yl_vec.size()!=static_cast<size_t>(sy_js)))return false;size_t max_b_idx=(size_t)h_o*ppr_val;if(w_o==0||h_o==0)return true;
    for(int i_t=0;i_t<wp_js;++i_t){for(int j_t=0;j_t<hp_js;++j_t){int m_s_js=i_t;int n_s_js=j_t;size_t tmp_idx;
    tmp_idx=static_cast<size_t>(std::floor(n_s_js/ssy_val)); if(sx_js > 0) tmp_idx %= sx_js; else if (tmp_idx != 0) return false; if(tmp_idx>=xl_vec.size() && sx_js > 0)return false; m_s_js = sx_js > 0 ? static_cast<int>(xl_vec[tmp_idx]*ssx_val+m_s_js)%wp_js : m_s_js % wp_js;
    tmp_idx=static_cast<size_t>(std::floor(m_s_js/ssx_val)); if(sx_js > 0) tmp_idx %= sx_js; else if (tmp_idx != 0) return false; if(tmp_idx>=xl_vec.size() && sx_js > 0)return false; m_s_js = sx_js > 0 ? static_cast<int>(xl_vec[tmp_idx]*ssx_val+(m_s_js%static_cast<int>(ssx_val))) : static_cast<int>(m_s_js%static_cast<int>(ssx_val));
    tmp_idx=static_cast<size_t>(std::floor(m_s_js/ssx_val)); if(sy_js > 0) tmp_idx %= sy_js; else if (tmp_idx != 0) return false; if(tmp_idx>=yl_vec.size() && sy_js > 0)return false; n_s_js = sy_js > 0 ? static_cast<int>(yl_vec[tmp_idx]*ssy_val+n_s_js)%hp_js : n_s_js % hp_js;
    tmp_idx=static_cast<size_t>(std::floor(n_s_js/ssy_val)); if(sy_js > 0) tmp_idx %= sy_js; else if (tmp_idx != 0) return false; if(tmp_idx>=yl_vec.size() && sy_js > 0)return false; n_s_js = sy_js > 0 ? static_cast<int>(yl_vec[tmp_idx]*ssy_val+(n_s_js%static_cast<int>(ssy_val))) : static_cast<int>(n_s_js%static_cast<int>(ssy_val));
    int rd_x=m_s_js%w1;int rd_y=n_s_js%h1;size_t src_b_idx=(size_t)rd_y*ppr_val+(size_t)rd_x;if(src_b_idx>=max_b_idx)return false;uint32_t px_val=in_buf[src_b_idx];
    if(i_t<w_o&&j_t<h_o){size_t tgt_b_idx=(size_t)j_t*ppr_val+(size_t)i_t;if(tgt_b_idx>=max_b_idx)return false;if(enc_mode)out_buf[tgt_b_idx]=px_val;else{out_buf[src_b_idx]=in_buf[tgt_b_idx];}}}}return true;}

bool processPixelScramble(uint32_t*in_ptr,uint32_t*out_ptr,int w_val,int h_val,unsigned int ppr_val,const std::string&k_str,bool enc_mode){
    if(w_val==0||h_val==0)return true;std::vector<size_t>xl_arr=generatePermutation_JS_MD5_compatible(w_val,k_str);std::vector<size_t>yl_arr=generatePermutation_JS_MD5_compatible(h_val,k_str);
    if((w_val>0&&xl_arr.size()!=static_cast<size_t>(w_val))||(h_val>0&&yl_arr.size()!=static_cast<size_t>(h_val)))return false;
    auto p_lambda=[&](int xt_val,int yt_val,int iW_val,int iH_val,unsigned int rp_val,size_t maxI_val,uint32_t*in_l,uint32_t*out_l){int ms_val=xt_val,ns_val=yt_val;
    if(iW_val>0&&!xl_arr.empty()){ size_t x_idx = static_cast<size_t>(ns_val); if(xl_arr.empty()) throw 1; x_idx %= xl_arr.size(); ms_val=(xl_arr[x_idx]+ms_val)%iW_val; x_idx = static_cast<size_t>(ms_val); if(xl_arr.empty()) throw 1; x_idx %= xl_arr.size(); ms_val=xl_arr[x_idx];} else if (iW_val > 0) {ms_val = 0; }
    if(iH_val>0&&!yl_arr.empty()){ size_t y_idx = static_cast<size_t>(ms_val); if(yl_arr.empty()) throw 1; y_idx %= yl_arr.size(); ns_val=(yl_arr[y_idx]+ns_val)%iH_val; y_idx = static_cast<size_t>(ns_val); if(yl_arr.empty()) throw 1; y_idx %= yl_arr.size(); ns_val=yl_arr[y_idx];} else if (iH_val > 0) {ns_val = 0; }
    size_t ti_val=(size_t)yt_val*rp_val+xt_val;size_t si_val=(size_t)ns_val*rp_val+ms_val;if(ti_val>=maxI_val||si_val>=maxI_val)throw 1;if(enc_mode)out_l[ti_val]=in_l[si_val];else out_l[si_val]=in_l[ti_val];};
    return processPixelsGeneric(in_ptr,out_ptr,w_val,h_val,ppr_val,p_lambda);}

bool processRowPixelScramble(uint32_t*in_ptr,uint32_t*out_ptr,int w_val,int h_val,unsigned int ppr_val,const std::string&k_str,bool enc_mode){
    if(w_val==0||h_val==0)return true;std::vector<size_t>xl_arr=generatePermutation_JS_MD5_compatible(w_val,k_str);if(w_val>0&&xl_arr.size()!=static_cast<size_t>(w_val))return false;
    auto p_lambda=[&](int xt_val,int yt_val,int iW_val,int /*iH_val*/,unsigned int rp_val,size_t maxI_val,uint32_t*in_l,uint32_t*out_l){int ms_val=xt_val,ns_val=yt_val;
    if(iW_val>0&&!xl_arr.empty()){ size_t x_idx = static_cast<size_t>(ns_val); if(xl_arr.empty()) throw 1; x_idx %= xl_arr.size(); ms_val=(xl_arr[x_idx]+ms_val)%iW_val; x_idx = static_cast<size_t>(ms_val); if(xl_arr.empty()) throw 1; x_idx %= xl_arr.size(); ms_val=xl_arr[x_idx];} else if (iW_val > 0) {ms_val = 0;}
    size_t ti_val=(size_t)yt_val*rp_val+xt_val;size_t si_val=(size_t)ns_val*rp_val+ms_val;if(ti_val>=maxI_val||si_val>=maxI_val)throw 1;if(enc_mode)out_l[ti_val]=in_l[si_val];else out_l[si_val]=in_l[ti_val];};
    return processPixelsGeneric(in_ptr,out_ptr,w_val,h_val,ppr_val,p_lambda);}

bool processPE1(uint32_t*in_ptr,uint32_t*out_ptr,int w_val,int h_val,unsigned int ppr_val,double kx0_val,bool enc_mode){
    if(w_val==0||h_val==0)return true;std::vector<size_t>pc_vec=generateLogisticPermutation(w_val,kx0_val);if((w_val>0&&(pc_vec.empty()||pc_vec.size()!=static_cast<size_t>(w_val))))return false;
    auto p_lambda=[&](int xt_val,int yt_val,int iW_val,int /*iH_val*/,unsigned int rp_val,size_t maxI_val,uint32_t*in_l,uint32_t*out_l){
    if (pc_vec.empty() && iW_val > 0) throw 1; // Should not happen if w_val > 0 and check above passed
    size_t sx_val = (iW_val > 0) ? pc_vec[static_cast<size_t>(xt_val) % pc_vec.size()] : 0; // Added modulo for safety, though xt_val should be < w_val
    int sy_val=yt_val;if(sx_val>=static_cast<size_t>(iW_val) && iW_val > 0)throw 1;
    size_t ti_val=(size_t)yt_val*rp_val+xt_val;size_t si_val=(size_t)sy_val*rp_val+sx_val;if(ti_val>=maxI_val||si_val>=maxI_val)throw 1;if(enc_mode)out_l[ti_val]=in_l[si_val];else out_l[si_val]=in_l[ti_val];};
    return processPixelsGeneric(in_ptr,out_ptr,w_val,h_val,ppr_val,p_lambda);}
/*
bool processPE2(uint32_t*in_buf,uint32_t*out_buf,int w_val,int h_val,unsigned int ppr_val,double kx0_val,bool enc_mode){
    if(w_val==0||h_val==0)return true;size_t buf_s_elements=(size_t)h_val*w_val; if(ppr_val == 0 && (w_val > 0 || h_val > 0)) return false; size_t buf_s_bytes=(size_t)h_val*ppr_val; std::vector<uint32_t>tmp_b(buf_s_elements);uint32_t*pt_buf=tmp_b.data();double cx_log=kx0_val;
    if(enc_mode){cx_log=kx0_val;for(int r_lp=0;r_lp<h_val;++r_lp){double ex_log;std::vector<size_t>p_arr=generateLogisticPermutation(w_val,cx_log,&ex_log);if(w_val>0&&(p_arr.empty()||p_arr.size()!=static_cast<size_t>(w_val)))return false;cx_log=ex_log;
    for(int ct_val=0;ct_val<w_val;++ct_val){size_t sc_val=(w_val>0?p_arr[static_cast<size_t>(ct_val)%p_arr.size()]:0);if(sc_val>=static_cast<size_t>(w_val) && w_val > 0)return false;size_t ti_idx_elem=(size_t)r_lp*w_val+ct_val;size_t si_idx_buf=(size_t)r_lp*ppr_val+sc_val; if(ti_idx_elem >= tmp_b.size() || si_idx_buf >= buf_s_bytes/sizeof(uint32_t) ) return false; pt_buf[ti_idx_elem]=in_buf[si_idx_buf];}}
    cx_log=kx0_val;for(int c_lp=0;c_lp<w_val;++c_lp){double ex_log;std::vector<size_t>p_arr=generateLogisticPermutation(h_val,cx_log,&ex_log);if(h_val>0&&(p_arr.empty()||p_arr.size()!=static_cast<size_t>(h_val)))return false;cx_log=ex_log;
    for(int rt_val=0;rt_val<h_val;++rt_val){size_t sr_val=(h_val>0?p_arr[static_cast<size_t>(rt_val)%p_arr.size()]:0);if(sr_val>=static_cast<size_t>(h_val) && h_val > 0)return false;size_t ti_idx_buf=(size_t)rt_val*ppr_val+c_lp;size_t si_idx_elem=sr_val*w_val+(size_t)c_lp; if(ti_idx_buf >= buf_s_bytes/sizeof(uint32_t) || si_idx_elem >= tmp_b.size()) return false; out_buf[ti_idx_buf]=pt_buf[si_idx_elem];}}}
    else{cx_log=kx0_val;for(int c_lp=0;c_lp<w_val;++c_lp){double ex_log;std::vector<size_t>p_arr=generateLogisticPermutation(h_val,cx_log,&ex_log);if(h_val>0&&(p_arr.empty()||p_arr.size()!=static_cast<size_t>(h_val)))return false;cx_log=ex_log;
    for(int re_val=0;re_val<h_val;++re_val){size_t Or_val=(h_val>0?p_arr[static_cast<size_t>(re_val)%p_arr.size()]:0);if(Or_val>=static_cast<size_t>(h_val) && h_val > 0)return false;size_t ei_idx_buf=(size_t)re_val*ppr_val+c_lp;size_t Oi_idx_elem=Or_val*w_val+(size_t)c_lp;if(ei_idx_buf >= buf_s_bytes/sizeof(uint32_t) || Oi_idx_elem >= tmp_b.size()) return false; pt_buf[Oi_idx_elem]=in_buf[ei_idx_buf];}}
    cx_log=kx0_val;for(int r_lp=0;r_lp<h_val;++r_lp){double ex_log;std::vector<size_t>p_arr=generateLogisticPermutation(w_val,cx_log,&ex_log);if(w_val>0&&(p_arr.empty()||p_arr.size()!=static_cast<size_t>(w_val)))return false;cx_log=ex_log;
    for(int ce_val=0;ce_val<w_val;++ce_val){size_t Oc_val=(w_val>0?p_arr[static_cast<size_t>(ce_val)%p_arr.size()]:0);if(Oc_val>=static_cast<size_t>(w_val) && w_val > 0)return false;size_t ei_idx_elem=(size_t)r_lp*w_val+ce_val;size_t Oi_idx_buf=(size_t)r_lp*ppr_val+Oc_val;if(ei_idx_elem >= tmp_b.size() || Oi_idx_buf >= buf_s_bytes/sizeof(uint32_t)) return false; out_buf[Oi_idx_buf]=pt_buf[ei_idx_elem];}}}
    return true;}
 */
template<typename FuncType,typename... ArgsType>jboolean processImageCommon(JNIEnv*env_ptr,jobject,jobject bmp_in,jobject bmp_out,const char*,FuncType proc_f,ArgsType...args_val){
    AndroidBitmapInfo info_in,info_out;void*pix_in=nullptr;void*pix_out=nullptr;int ret_val;if((ret_val=AndroidBitmap_getInfo(env_ptr,bmp_in,&info_in))<0)return JNI_FALSE;if((ret_val=AndroidBitmap_getInfo(env_ptr,bmp_out,&info_out))<0)return JNI_FALSE;
    if(info_in.format!=ANDROID_BITMAP_FORMAT_RGBA_8888)return JNI_FALSE;if(info_out.format!=info_in.format)return JNI_FALSE;if(info_in.width!=info_out.width||info_in.height!=info_out.height)return JNI_FALSE;
    if(info_in.width>0&&info_in.stride<(info_in.width*4))return JNI_FALSE;if(info_out.stride!=info_in.stride)return JNI_FALSE;int w_val=(int)info_in.width;int h_val=(int)info_in.height;unsigned int ppr_s_val=(w_val>0)?(info_in.stride/4):0;
    if(w_val==0||h_val==0)return JNI_TRUE;if((ret_val=AndroidBitmap_lockPixels(env_ptr,bmp_in,&pix_in))<0)return JNI_FALSE;if((ret_val=AndroidBitmap_lockPixels(env_ptr,bmp_out,&pix_out))<0){AndroidBitmap_unlockPixels(env_ptr,bmp_in);return JNI_FALSE;}
    if(!pix_in||!pix_out){if(pix_in)AndroidBitmap_unlockPixels(env_ptr,bmp_in);if(pix_out)AndroidBitmap_unlockPixels(env_ptr,bmp_out);return JNI_FALSE;}
    bool success_flag=false;try{success_flag=proc_f(reinterpret_cast<uint32_t*>(pix_in),reinterpret_cast<uint32_t*>(pix_out),w_val,h_val,ppr_s_val,args_val...);}catch(...){success_flag=false;}
    AndroidBitmap_unlockPixels(env_ptr,bmp_out);AndroidBitmap_unlockPixels(env_ptr,bmp_in);return success_flag?JNI_TRUE:JNI_FALSE;}

extern"C" JNIEXPORT jboolean JNICALL Java_io_github_fqt_MainActivity_nativeProcessImage(JNIEnv*e,jobject t,jobject bi,jobject bo,jboolean em){return processImageCommon(e,t,bi,bo,nullptr,processGilbert,(bool)em);}
extern"C" JNIEXPORT jboolean JNICALL Java_io_github_fqt_MainActivity_nativeProcessBlockScramble(JNIEnv*e,jobject t,jobject bi,jobject bo,jstring k,jint sx,jint sy,jboolean em){const char*ck=e->GetStringUTFChars(k,nullptr);if(!ck)return JNI_FALSE;std::string sk=ck;e->ReleaseStringUTFChars(k,ck);return processImageCommon(e,t,bi,bo,nullptr,processBlockScramble,sk,(int)sx,(int)sy,(bool)em);}
extern"C" JNIEXPORT jboolean JNICALL Java_io_github_fqt_MainActivity_nativeProcessPixelScramble(JNIEnv*e,jobject t,jobject bi,jobject bo,jstring k,jboolean em){const char*ck=e->GetStringUTFChars(k,nullptr);if(!ck)return JNI_FALSE;std::string sk=ck;e->ReleaseStringUTFChars(k,ck);return processImageCommon(e,t,bi,bo,nullptr,processPixelScramble,sk,(bool)em);}
extern"C" JNIEXPORT jboolean JNICALL Java_io_github_fqt_MainActivity_nativeProcessRowPixelScramble(JNIEnv*e,jobject t,jobject bi,jobject bo,jstring k,jboolean em){const char*ck=e->GetStringUTFChars(k,nullptr);if(!ck)return JNI_FALSE;std::string sk=ck;e->ReleaseStringUTFChars(k,ck);return processImageCommon(e,t,bi,bo,nullptr,processRowPixelScramble,sk,(bool)em);}
extern"C" JNIEXPORT jboolean JNICALL Java_io_github_fqt_MainActivity_nativeProcessPE1(JNIEnv*e,jobject t,jobject bi,jobject bo,jdouble kx0,jboolean em){double x0_val=(double)kx0;if(x0_val<=0||x0_val>=1)return JNI_FALSE;return processImageCommon(e,t,bi,bo,nullptr,processPE1,x0_val,(bool)em);}
extern"C" JNIEXPORT jboolean JNICALL Java_io_github_fqt_MainActivity_nativeProcessPE2(JNIEnv*e,jobject t,jobject bi,jobject bo,jdouble kx0,jboolean em){double x0_val=(double)kx0;if(x0_val<=0||x0_val>=1)return JNI_FALSE;return processImageCommon(e,t,bi,bo,nullptr,processPE2,x0_val,(bool)em);}
