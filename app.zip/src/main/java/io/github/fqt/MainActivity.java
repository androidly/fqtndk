package io.github.fqt; // 确保这是你的包名

import android.*;
import android.annotation.*;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.content.res.*;
import android.database.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.support.v4.content.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class MainActivity extends Activity {

	private static final String TAG = "MainActivity";
	private static final int PICK_IMAGE_REQUEST = 1;
	private static final int PERMISSION_REQUEST_READ_STORAGE = 101;
	private static final int PERMISSION_REQUEST_WRITE_STORAGE = 102;
	private static final int THUMBNAIL_SIZE = 150;
	private static final int MAX_LOAD_DIMENSION = 8192;
	private static final int MENU_ITEM_ABOUT_ID = 1;
	private static final int DEFAULT_BLOCK_SIZE_X = 32;
	private static final int DEFAULT_BLOCK_SIZE_Y = 32;
	private static final int JPEG_COMPRESSION_QUALITY = 95; // 为JPEG添加压缩质量
	private static final boolean DEBUG_IMAGE_LOADING = true;
	
	private ImageView mainImageView;
	private TextView statusTextView;
	private HorizontalScrollView thumbnailScrollView;
	private LinearLayout thumbnailLayout;
	private LinearLayout bottomActionLayout;
	private LinearLayout batchActionLayout;
	private Button initialAddButton;
	private Button btnObfuscate;
	private Button btnDeobfuscate;
	private Button btnRevert;
	private Button btnClear;
	private Button btnSave;

	private Button btnBatchObfuscate;
	private Button btnBatchDeobfuscate;
	private Button btnBatchRevert;
	private Button btnBatchClear;
	private Button btnBatchSave;

	private ProgressBar progressBar;
	private View mainImageContainer;
	private LinearLayout keyInputLayout;

	private LinearLayout controlsLayout;
	private Spinner algorithmSpinner;
	private EditText keyStringEditText;
	private EditText keyDoubleEditText;
	private TextView infoTextView;

  // 新增：横幅通知相关的视图和处理器
  private View notificationBannerRoot; // 这是 banner_notification.xml 布局的根视图 (LinearLayout with id banner_container)
  private TextView bannerTextView;
  private ImageView bannerCloseButton;
  private Handler bannerDisplayHandler = new Handler(Looper.getMainLooper()); // 用于延迟隐藏横幅
  private Runnable hideBannerRunnable; // 用于存储隐藏横幅的任务
	
	private ArrayList<ImageData> selectedImages = new ArrayList<ImageData>();
	private int currentlyDisplayedIndex = -1;
	private String currentAlgorithmMode = "gilbert"; // 初始值，会被Spinner覆盖

	private final ExecutorService executor = Executors.newFixedThreadPool(2);
	private final Handler mainHandler = new Handler(Looper.getMainLooper());
	private GestureDetector gestureDetector;

	private boolean b2InputWasPadded;

	private StringBuilder debugLogBuilder = new StringBuilder(); // 用于累加日志
	private static final int MAX_LOG_LINES = 100; // 限制日志行数，防止内存问题
	private int currentLogLines = 0;

	// ... (native 方法等) ...

	private native boolean nativeProcessImage(Bitmap bitmapIn, Bitmap bitmapOut, boolean encryptMode);
	public native boolean nativeProcessBlockScramble(Bitmap bitmapIn, Bitmap bitmapOut, String key, int sx, int sy,
			boolean encryptMode);
	public native boolean nativeProcessPixelScramble(Bitmap bitmapIn, Bitmap bitmapOut, String key,
			boolean encryptMode);
	public native boolean nativeProcessRowPixelScramble(Bitmap bitmapIn, Bitmap bitmapOut, String key,
			boolean encryptMode);
	public native boolean nativeProcessPE1(Bitmap bitmapIn, Bitmap bitmapOut, double key_x0, boolean encryptMode);
	public native boolean nativeProcessPE2(Bitmap bitmapIn, Bitmap bitmapOut, double key_x0, boolean encryptMode);

	public native String getMenuItemAboutText();
	public native String getDialogTitle();
	public native String getDialogMessage();
	public native String getDialogButtonText();

	static {
		try {
			System.loadLibrary("fqt");
		} catch (UnsatisfiedLinkError e) {
			System.err.println("Native code library failed to load.\n" + e);
			Log.e(TAG, "本地库加载失败", e);
		}
	}

	private static class ImageData {
		Uri originalUri;
		Bitmap currentBitmap;
		Bitmap thumbnail;
		boolean isLoadingFull = false;
		boolean isLoadingThumb = false;
		ImageData(Uri uri) {
			this.originalUri = uri;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (getResources().getIdentifier("main", "layout", getPackageName()) == 0) {
			Log.e(TAG, "FATAL ERROR: main.xml layout not found!");
			appendLog("onCreate: Activity创建"); // 记录Activity创建
			Toast.makeText(this, getString(R.string.app_name) + ": " + getString(R.string.layout_file_missing_error),
					Toast.LENGTH_LONG).show();
			finish();
			return;
		}
		setContentView(R.layout.main);
		bindViews();
		showBanner(getString(R.string.please_select_image),false);
		if (!checkViewsBound()) {
			Log.e(TAG, "FATAL ERROR: One or more views not found in layout! Check IDs in main.xml");
			Toast.makeText(this, getString(R.string.app_name) + ": " + getString(R.string.view_id_mismatch_error),
					Toast.LENGTH_LONG).show();
			finish();
			return;
		}
		setupAlgorithmSpinner(); // 这会设置 currentAlgorithmMode
		setupButtonClickListeners();
		setupGestureDetector();
		setupBannerCloseButton(); // <--- 新增调用
		updateUiVisibility();
		updateStatusText();
		updateInfoText(null, -1);
	}
	
  private void setupBannerCloseButton() {
    if (bannerCloseButton != null) {
	  bannerCloseButton.setOnClickListener(new View.OnClickListener() {
		  @Override
		  public void onClick(View v) {
			hideBanner(false); // true 表示立即隐藏，无动画或动画非常快
		  }
        });
    }
  }
  
  
  private void showBanner(final String message, final boolean isError) {
    // 检查视图是否已正确初始化
    if (notificationBannerRoot == null || bannerTextView == null) {
	  Log.e(TAG, "Banner views not initialized. Cannot show banner. Message: " + message);
	  // 可以选择在这里回退到 Toast，或者什么都不做
	 showToast("a123");
	  // showOldToastFallback(message); // 假设你有一个旧的 Toast 方法作为备用
	  return;
    }

    // 如果有正在执行的隐藏任务，先移除它
    if (hideBannerRunnable != null) {
	  bannerDisplayHandler.removeCallbacks(hideBannerRunnable);
    }

    mainHandler.post(new Runnable() { // 确保在UI线程操作视图
        @Override
        public void run() {
		  bannerTextView.setText(message);
		  if (isError) {
			notificationBannerRoot.setBackgroundColor(0xDDEF5350); // 半透明红色 (错误)
		  } else {
			notificationBannerRoot.setBackgroundColor(0xDD4CAF50); // 半透明绿色 (成功)
		  }

		  if (notificationBannerRoot.getVisibility() != View.VISIBLE) {
			notificationBannerRoot.setVisibility(View.VISIBLE);
			AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
			fadeIn.setDuration(300); // 淡入动画时长
			notificationBannerRoot.startAnimation(fadeIn);
		  } else {
			// 如果横幅已显示，可能只是更新文本和背景，不需要动画
			// 或者可以加一个轻微的强调动画
		  }

		  // 定义隐藏任务
		  hideBannerRunnable = new Runnable() {
			@Override
			public void run() {
			  hideBanner(false); // false 表示带动画隐藏
			}
		  };

		  // 根据消息长度和是否为错误，设置不同的显示时长
		  long durationMillis = 3500; // 默认3.5秒
		  if (message != null && message.length() > 80) { // 较长的消息
			durationMillis = 5000; // 5秒
		  }
		  if (isError) {
			durationMillis += 1500; // 错误消息多停留1.5秒
		  }
		  bannerDisplayHandler.postDelayed(hideBannerRunnable, durationMillis);
        }
	  });
  }

  private void hideBanner(boolean immediate) {
    if (notificationBannerRoot != null && notificationBannerRoot.getVisibility() == View.VISIBLE) {
	  // 确保移除任何计划中的隐藏任务，防止重复或冲突
	  if (hideBannerRunnable != null) {
		bannerDisplayHandler.removeCallbacks(hideBannerRunnable);
		hideBannerRunnable = null; // 清除引用
	  }

	  if (immediate) {
		notificationBannerRoot.setVisibility(View.GONE);
		// 如果有动画正在播放，可能需要取消
		notificationBannerRoot.clearAnimation();
	  } else {
		AlphaAnimation fadeOut = new AlphaAnimation(1.0f, 0.0f);
		fadeOut.setDuration(300); // 淡出动画时长
		fadeOut.setAnimationListener(new Animation.AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {}

			@Override
			public void onAnimationEnd(Animation animation) {
			  // 动画结束后才设置为 GONE，这样动画才能完整播放
			  if (notificationBannerRoot != null) { // 再次检查，以防万一
				notificationBannerRoot.setVisibility(View.GONE);
			  }
			}
			@Override
			public void onAnimationRepeat(Animation animation) {}
		  });
		notificationBannerRoot.startAnimation(fadeOut);
	  }
    }
  }
  
/*
	private void bindViews() {
		mainImageView = (ImageView) findViewById(R.id.mainImageView);
	  
		mainImageContainer = findViewById(R.id.mainImageContainer);
		statusTextView = (TextView) findViewById(R.id.statusTextView);
		thumbnailScrollView = (HorizontalScrollView) findViewById(R.id.thumbnailScrollView);
		thumbnailLayout = (LinearLayout) findViewById(R.id.thumbnailLayout);
		bottomActionLayout = (LinearLayout) findViewById(R.id.bottomActionLayout);
		batchActionLayout = (LinearLayout) findViewById(R.id.batchActionLayout);
		initialAddButton = (Button) findViewById(R.id.initialAddButton);
		btnObfuscate = (Button) findViewById(R.id.btnObfuscate);
		btnDeobfuscate = (Button) findViewById(R.id.btnDeobfuscate);
		btnRevert = (Button) findViewById(R.id.btnRevert);
		btnClear = (Button) findViewById(R.id.btnClear);
		btnSave = (Button) findViewById(R.id.btnSave);

		btnBatchObfuscate = (Button) findViewById(R.id.btnBatchObfuscate);
		btnBatchDeobfuscate = (Button) findViewById(R.id.btnBatchDeobfuscate);
		btnBatchRevert = (Button) findViewById(R.id.btnBatchRevert);
		btnBatchClear = (Button) findViewById(R.id.btnBatchClear);
		btnBatchSave = (Button) findViewById(R.id.btnBatchSave);

	  
		progressBar = (ProgressBar) findViewById(R.id.progressBar);
		keyInputLayout = (LinearLayout) findViewById(R.id.keyInputLayout);
		controlsLayout = (LinearLayout) findViewById(R.id.controlsLayout);
		algorithmSpinner = (Spinner) findViewById(R.id.algorithmSpinner);
		keyStringEditText = (EditText) findViewById(R.id.keyStringEditText);
		keyDoubleEditText = (EditText) findViewById(R.id.keyDoubleEditText);
		infoTextView = (TextView) findViewById(R.id.infoTextView);
		
	  View bannerIncludeLayout = findViewById(R.id.notification_banner_include);
	  notificationBannerRoot = findViewById(R.id.notification_banner_include); // 直接尝试用 include 的 ID

	  if (notificationBannerRoot != null) {
		if (notificationBannerRoot.getId() == R.id.banner_container) { // 检查一下是不是直接拿到了 banner_container
		  Log.d(TAG, "findViewById(R.id.notification_banner_include) directly returned banner_container.");
        } else {View tempBannerContainer = notificationBannerRoot.findViewById(R.id.banner_container);
		  if (tempBannerContainer != null) {
			Log.d(TAG, "Found banner_container within notification_banner_include.");
			notificationBannerRoot = tempBannerContainer; // 更新为真正的 banner_container
		  } else {
			return; // 无法继续
		  }
        }
		bannerTextView = notificationBannerRoot.findViewById(R.id.banner_text);
        bannerCloseButton = notificationBannerRoot.findViewById(R.id.banner_close_button);

        if (bannerTextView == null) Log.e(TAG, "banner_text is NULL after attempting to find it in notificationBannerRoot!");
        if (bannerCloseButton == null) Log.e(TAG, "banner_close_button is NULL after attempting to find it in notificationBannerRoot!");
	  } else {
        Log.e(TAG, "FATAL: R.id.notification_banner_include (the <include> tag itself) not found in main.xml!");
	  }
		/*
	  if (bannerIncludeLayout != null) {
        // 然后从这个 include 的布局中找到 banner_container (它是 banner_notification.xml 的根 LinearLayout)
        notificationBannerRoot = bannerIncludeLayout.findViewById(R.id.banner_container);
        if (notificationBannerRoot != null) {
		  bannerTextView = notificationBannerRoot.findViewById(R.id.banner_text);
		  bannerCloseButton = notificationBannerRoot.findViewById(R.id.banner_close_button);

		  // 可以在这里检查 bannerTextView 和 bannerCloseButton 是否也为 null，并记录日志
		  if (bannerTextView == null) Log.e(TAG, "banner_text not found within banner_container!");
		  if (bannerCloseButton == null) Log.e(TAG, "banner_close_button not found within banner_container!");

        } else {
		  Log.e(TAG, "R.id.banner_container (root of banner_notification.xml) not found within the included layout.");
		  // 在这种情况下，横幅功能将无法工作
        }
	  } else {
        Log.e(TAG, "FATAL: R.id.notification_banner_include (the <include> tag itself) not found in main.xml!");
        // 横幅功能将无法工作
	  }

	
	}
	*/
  // ... (在 MainActivity.java 中) ...

  private void bindViews() {
    // --- 绑定主布局中的常规视图 ---
    mainImageView = (ImageView) findViewById(R.id.mainImageView);
    mainImageContainer = findViewById(R.id.mainImageContainer);
    statusTextView = (TextView) findViewById(R.id.statusTextView);
    thumbnailScrollView = (HorizontalScrollView) findViewById(R.id.thumbnailScrollView);
    thumbnailLayout = (LinearLayout) findViewById(R.id.thumbnailLayout);
    bottomActionLayout = (LinearLayout) findViewById(R.id.bottomActionLayout);
    batchActionLayout = (LinearLayout) findViewById(R.id.batchActionLayout);
    initialAddButton = (Button) findViewById(R.id.initialAddButton);
    btnObfuscate = (Button) findViewById(R.id.btnObfuscate);
    btnDeobfuscate = (Button) findViewById(R.id.btnDeobfuscate);
    btnRevert = (Button) findViewById(R.id.btnRevert);
    btnClear = (Button) findViewById(R.id.btnClear);
    btnSave = (Button) findViewById(R.id.btnSave);

    btnBatchObfuscate = (Button) findViewById(R.id.btnBatchObfuscate);
    btnBatchDeobfuscate = (Button) findViewById(R.id.btnBatchDeobfuscate);
    btnBatchRevert = (Button) findViewById(R.id.btnBatchRevert);
    btnBatchClear = (Button) findViewById(R.id.btnBatchClear);
    btnBatchSave = (Button) findViewById(R.id.btnBatchSave);

    // progressBar 是全局的，在 RelativeLayout 的直接子级
    progressBar = (ProgressBar) findViewById(R.id.progressBar); 
    keyInputLayout = (LinearLayout) findViewById(R.id.keyInputLayout);
    controlsLayout = (LinearLayout) findViewById(R.id.controlsLayout);
    algorithmSpinner = (Spinner) findViewById(R.id.algorithmSpinner);
    keyStringEditText = (EditText) findViewById(R.id.keyStringEditText);
    keyDoubleEditText = (EditText) findViewById(R.id.keyDoubleEditText);
    infoTextView = (TextView) findViewById(R.id.infoTextView);

    // --- 绑定横幅通知视图 ---
    // R.id.notification_banner_include 是你在 main.xml 中为 <include> 标签设置的 ID。
    // findViewById(R.id.notification_banner_include) 会返回被包含布局 (banner_notification.xml) 的根视图。
    // 在你的 banner_notification.xml 中，根视图是 <LinearLayout android:id="@+id/banner_container">。
    // 所以，下面这行代码应该能直接获取到那个 LinearLayout。
    notificationBannerRoot = findViewById(R.id.notification_banner_include);

    if (notificationBannerRoot != null) {
	  // 现在 notificationBannerRoot 应该就是 banner_container LinearLayout。
	  // 我们可以从中查找 banner_text 和 banner_close_button。

	  // （可选的调试验证）
	  if (notificationBannerRoot.getId() == R.id.banner_container) {
		Log.d(TAG, "bindViews: Correctly fetched 'banner_container' using the <include> tag's ID 'notification_banner_include'.");
	  } else {
		// 如果ID不匹配，这表示 <include> 标签的 ID 和被包含布局的根 ID 不同，
		// 或者被包含布局的根根本没有 R.id.banner_container 这个 ID。
		// 但通常，如果 banner_notification.xml 的根是 <LinearLayout android:id="@+id/banner_container">,
		// 那么 findViewById(R.id.notification_banner_include) 就会返回这个 LinearLayout。
		Log.w(TAG, "bindViews: The View fetched by 'notification_banner_include' does not have the ID 'banner_container'. " +
			  "Actual ID: " + (notificationBannerRoot.getId() != View.NO_ID ? getResources().getResourceEntryName(notificationBannerRoot.getId()) : "NO_ID") +
			  ". This might be an issue if banner_notification.xml's root ID is different or missing.");
	  }

	  bannerTextView = notificationBannerRoot.findViewById(R.id.banner_text);
	  bannerCloseButton = notificationBannerRoot.findViewById(R.id.banner_close_button);

	  if (bannerTextView == null) {
		Log.e(TAG, "bindViews: banner_text (R.id.banner_text) is NULL! Check banner_notification.xml.");
	  }
	  if (bannerCloseButton == null) {
		Log.e(TAG, "bindViews: banner_close_button (R.id.banner_close_button) is NULL! Check banner_notification.xml.");
	  }
    } else {
	  Log.e(TAG, "bindViews: FATAL! R.id.notification_banner_include (the <include> tag itself) not found in main.xml!");
	  // 在这种情况下，横幅功能将无法使用，notificationBannerRoot, bannerTextView, bannerCloseButton 都会是 null。
    }
  }
	

	private boolean checkViewsBound() {
		return mainImageView != null && mainImageContainer != null && statusTextView != null
				&& thumbnailScrollView != null && thumbnailLayout != null && bottomActionLayout != null
				&& initialAddButton != null && btnObfuscate != null && btnDeobfuscate != null && btnRevert != null
				&& btnClear != null && btnSave != null && btnBatchObfuscate != null && btnBatchDeobfuscate != null
				&& btnBatchRevert != null && btnBatchClear != null && btnBatchSave != null && progressBar != null
				&& controlsLayout != null && algorithmSpinner != null && keyStringEditText != null
				&& keyDoubleEditText != null && infoTextView != null && keyInputLayout != null
				
				;
	}

	private void setupAlgorithmSpinner() {
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.algorithm_modes,
				android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		algorithmSpinner.setAdapter(adapter);
		algorithmSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				updateKeyInputVisibility(position); // This will set currentAlgorithmMode
			}
			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				updateKeyInputVisibility(0); // This will set currentAlgorithmMode
			}
		});
		updateKeyInputVisibility(algorithmSpinner.getSelectedItemPosition()); // Initial set
	}

	private void updateKeyInputVisibility(int selectedPosition) {
		boolean useDoubleKey = false;
		boolean needsKey = true;

		try {
			String[] algorithmValues = getResources().getStringArray(R.array.algorithm_values);
			if (selectedPosition >= 0 && selectedPosition < algorithmValues.length) {
				currentAlgorithmMode = algorithmValues[selectedPosition];
			} else {
				Log.w(TAG, "Selected position " + selectedPosition
						+ " is out of bounds for algorithm_values. Defaulting to gilbert.");
				currentAlgorithmMode = "gilbert"; // Default if something goes wrong
			}
		} catch (Resources.NotFoundException e) {
			Log.e(TAG, "FATAL: R.array.algorithm_values not found in strings.xml! Defaulting to gilbert.", e);
			showBanner(("错误: 算法列表配置缺失! 将默认使用Gilbert模式。"),true);
			currentAlgorithmMode = "gilbert"; // Default
		}
		Log.d(TAG, "Current algorithm mode set to: " + currentAlgorithmMode);

		switch (currentAlgorithmMode) {
			case "gilbert" :
				needsKey = false;
				break;
			case "b" :
			case "c" :
			case "c2" :
				useDoubleKey = false;
				break;
			case "pe1" :
			case "pe2" :
				useDoubleKey = true;
				break;
			default :
				Log.w(TAG, "Unknown algorithm mode encountered in spinner: " + currentAlgorithmMode
						+ ". Defaulting to gilbert (for key visibility).");
				// Keep currentAlgorithmMode as is for processing, but adjust UI as if gilbert
				needsKey = false; // Assuming unknown types don't need keys for UI
				break;
		}

		if (keyInputLayout != null) {
			keyInputLayout.setVisibility(needsKey ? View.VISIBLE : View.GONE);
		}

		if (needsKey) {
			if (keyStringEditText != null) {
				keyStringEditText.setVisibility(useDoubleKey ? View.GONE : View.VISIBLE);
			}
			if (keyDoubleEditText != null) {
				keyDoubleEditText.setVisibility(useDoubleKey ? View.VISIBLE : View.GONE);
			}
		} else {
			if (keyStringEditText != null) {
				keyStringEditText.setVisibility(View.GONE);
			}
			if (keyDoubleEditText != null) {
				keyDoubleEditText.setVisibility(View.GONE);
			}
		}
	}

	private void setupButtonClickListeners() {
		initialAddButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				checkReadPermissionAndPickImage();
			}
		});
		btnObfuscate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (isSelectionEmpty())
					return;
				processImageInternal(true); // isObfuscate = true

			}
		});
		btnDeobfuscate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (isSelectionEmpty())
					return;
				processImageInternal(false);
			}
		});
		btnRevert.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				//帮我添加单图的还原，参考全部的逻辑
			  if (!isValidIndex(currentlyDisplayedIndex)) {
				showBanner(getString(R.string.no_image_selected_for_action),false);
				return;
			  }
			  revertSingleImageAsync(currentlyDisplayedIndex);
			
			}
		});
		btnClear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!isValidIndex(currentlyDisplayedIndex)) {
					return;
				}
				RemoveImageFormButton(currentlyDisplayedIndex);

			}
		});
		btnSave.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				checkWritePermissionAndSaveImage();
			}
		});

		btnBatchObfuscate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (isSelectionEmpty())
					return;
				// 如果只有一张图片，可以直接调用单张处理，或者让 processAllImagesAsync 自己处理
				if (selectedImages.size() == 1) {
					processImageInternal(true);
				} else {
					processAllImagesAsync(true); // isObfuscate = true
				}
			}
		});
		btnBatchDeobfuscate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (isSelectionEmpty())
					return;
				if (selectedImages.size() == 1) {
					processImageInternal(false);
				} else {
					processAllImagesAsync(false); // isObfuscate = false
				}
			}
		});
		btnBatchRevert.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				revertAllImagesAsync();
			}
		});
		btnBatchClear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				confirmClearAll();

			}
		});
		btnBatchSave.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (isSelectionEmpty())
					return;
				if (selectedImages.size() == 1) {
					checkWritePermissionAndSaveImage();
				} else {
					checkWritePermissionAndSaveAllImages();
				}
			}
		});
	}

	private boolean isSelectionEmpty() {
		if (selectedImages == null || selectedImages.isEmpty()) {
			showBanner(getString(R.string.no_image_selected_for_action),false);
			return true;
		}
		return false;
	}

	@SuppressLint("ClickableViewAccessibility")
	private void setupGestureDetector() {
		gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
			private static final int SWIPE_THRESHOLD = 100, SWIPE_VELOCITY_THRESHOLD = 100;
			@Override
			public boolean onDown(MotionEvent e) {
				return !selectedImages.isEmpty();
			}
			@Override
			public boolean onFling(MotionEvent e1, MotionEvent e2, float vX, float vY) {
				if (e1 == null || e2 == null || selectedImages.size() <= 1)
					return false;
				float dX = e2.getX() - e1.getX();
				if (Math.abs(dX) > Math.abs(e2.getY() - e1.getY()) && Math.abs(dX) > SWIPE_THRESHOLD
						&& Math.abs(vX) > SWIPE_VELOCITY_THRESHOLD) {
					if (dX > 0)
						switchToPreviousImage();
					else
						switchToNextImage();
					return true;
				}
				return false;
			}
			@Override
			public void onLongPress(MotionEvent e) {
				if (isValidIndex(currentlyDisplayedIndex))
					showImageOptionsDialog(currentlyDisplayedIndex);
			}
		});
		mainImageContainer.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				return gestureDetector.onTouchEvent(event);
			}
		});
	}

	private void checkReadPermissionAndPickImage() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
				requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
						PERMISSION_REQUEST_READ_STORAGE);
			} else
				pickImage();
		} else
			pickImage();
	}

	private void pickImage() {
		Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
		intent.setType("image/*");
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2)
			intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		try {
			startActivityForResult(Intent.createChooser(intent, getString(R.string.option_open)), PICK_IMAGE_REQUEST);
		} catch (Exception ex) {
			showBanner((getString(R.string.cannot_open_file) + " (" + getString(R.string.install_file_manager_prompt)
					+ ")"),true);
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
			int newlyAddedCount = 0, firstAddedIdx = -1;
			ArrayList<Uri> uris = new ArrayList<Uri>();
			if (data.getClipData() != null) {
				for (int i = 0; i < data.getClipData().getItemCount(); i++)
					uris.add(data.getClipData().getItemAt(i).getUri());
			} else if (data.getData() != null) {
				uris.add(data.getData());
			}

			for (Uri uri : uris) {
				if (uri != null && addSelectedImage(uri)) {
					newlyAddedCount++;
					if (firstAddedIdx == -1)
						firstAddedIdx = selectedImages.size() - 1;
				}
			}
			if (newlyAddedCount > 0) {
				if (currentlyDisplayedIndex == -1 && firstAddedIdx != -1)
					currentlyDisplayedIndex = firstAddedIdx;
				updateUiVisibility();
				updateStatusText();
				refreshThumbnailView();
				if (isValidIndex(currentlyDisplayedIndex))
					loadFullImageAsync(currentlyDisplayedIndex);
				else {
					mainImageView.setImageDrawable(null);
					updateInfoText(null, -1);
				}
			}
		} else if (requestCode == PICK_IMAGE_REQUEST && resultCode != Activity.RESULT_CANCELED) {
			showBanner(getString(R.string.no) + " " + getString(R.string.selection_failed_suffix),false);
		}
	}

	private boolean addSelectedImage(Uri uri) {
		for (ImageData id : selectedImages)
			if (id.originalUri.equals(uri))
				return false;
		selectedImages.add(new ImageData(uri));
		return true;
	}

	@SuppressLint("ClickableViewAccessibility")
	private void refreshThumbnailView() {
		thumbnailLayout.removeAllViews();
		for (int i = 0; i < selectedImages.size(); i++) {
			final int index = i;
			final ImageData data = selectedImages.get(i);
			ImageView thumbView = new ImageView(this);
			LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(THUMBNAIL_SIZE, THUMBNAIL_SIZE);
			params.setMargins(5, 5, 5, 5);
			thumbView.setLayoutParams(params);
			thumbView.setScaleType(ImageView.ScaleType.CENTER_CROP);
			thumbView.setTag(index);
			thumbView.setBackgroundColor(0xFF363636);
			if (data.thumbnail != null && !data.thumbnail.isRecycled()) {
				thumbView.setImageBitmap(data.thumbnail);
				thumbView.setBackgroundColor(Color.TRANSPARENT);
			} else {
				loadThumbnailAsync(data, thumbView);
			}
			thumbView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					int ci = (Integer) v.getTag();
					if (isValidIndex(ci) && currentlyDisplayedIndex != ci) {
						currentlyDisplayedIndex = ci;
						loadFullImageAsync(ci);
					}
				}
			});
			thumbView.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View v) {
					int lci = (Integer) v.getTag();
					if (isValidIndex(lci))
						confirmRemoveImage(lci);
					return true;
				}
			});
			thumbnailLayout.addView(thumbView);
		}
		addThumbnailAddButton();
		highlightThumbnail(currentlyDisplayedIndex);
	}
	

	private void addThumbnailAddButton() {
		Button addButton = new Button(this);
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(THUMBNAIL_SIZE, THUMBNAIL_SIZE);
		params.setMargins(10, 5, 5, 5);
		addButton.setLayoutParams(params);
		addButton.setText(R.string.add_image);
		addButton.setTextSize(24);
		addButton.setTextColor(0xFF666666);
		try {
			addButton.setBackgroundResource(R.drawable.add_button_background);
		} catch (Exception e) {
			Log.w(TAG, "R.drawable.add_button_background not found, using default button background.");
		}
		addButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				checkReadPermissionAndPickImage();
			}
		});
		thumbnailLayout.addView(addButton);
	}
/*
	
  private int calculateInSampleSize(BitmapFactory.Options opt, int reqW, int reqH) {
    if (opt == null || opt.outWidth <= 0 || opt.outHeight <= 0 || reqW <= 0 || reqH <= 0)
	  return 1;
    final int h = opt.outHeight, w = opt.outWidth;
    int s = 1;
    if (h > reqH || w > reqW) {
	  final int halfH = h / 8;
	  final int halfW = w / 8;
	  while ((halfH / s) >= reqH && (halfW / s) >= reqW) {
		s *= 2;
	  }
    }
    Log.d(TAG, "calculateInSampleSize: req=" + reqW + "x" + reqH + ", original=" + w + "x" + h + " -> sampleSize=" + s);
    return s;
  }
	*/
  private Bitmap loadSampledThumbnailBitmap(Uri uri, int reqWidth, int reqHeight) {
    if (uri == null) {
	  Log.w(TAG, "loadSampledThumbnailBitmap: URI is null");
	  return null;
    }
    InputStream inputStream = null;
    try {
	  // Pass 1: Get dimensions
	  BitmapFactory.Options options = new BitmapFactory.Options();
	  options.inJustDecodeBounds = true;
	  inputStream = getContentResolver().openInputStream(uri);
	  if (inputStream == null) {
		Log.e(TAG, "loadSampledThumbnailBitmap: Cannot open stream (pass 1) for URI: " + uri);
		return null;
	  }
	  BitmapFactory.decodeStream(inputStream, null, options);
	  try { inputStream.close(); } catch (IOException ignored) {}

	  if (options.outWidth <= 0 || options.outHeight <= 0) {
		Log.e(TAG, "loadSampledThumbnailBitmap: Failed to get dimensions (pass 1) for URI: " + uri +
			  " (w=" + options.outWidth + ",h=" + options.outHeight + ")");
		// 你可以在这里添加一个UI线程的toast提示用户图片格式问题
		return null;
	  }

	  
	  
	  // Calculate inSampleSize
	  options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
	  options.inJustDecodeBounds = false;
	  // 对于缩略图，可以考虑 RGB_565 以节省内存，但 ARGB_8888 质量更好
	  options.inPreferredConfig = Bitmap.Config.RGB_565; 

	  // Pass 2: Decode actual bitmap
	  inputStream = getContentResolver().openInputStream(uri);
	  if (inputStream == null) {
		Log.e(TAG, "loadSampledThumbnailBitmap: Cannot open stream (pass 2) for URI: " + uri);
		return null;
	  }
	  Bitmap bmp = BitmapFactory.decodeStream(inputStream, null, options);
	  if (bmp == null) {
		Log.e(TAG, "loadSampledThumbnailBitmap: decodeStream returned null (pass 2) for URI: " + uri +
			  " with sampleSize: " + options.inSampleSize);
	  } else {
		Log.d(TAG, "loadSampledThumbnailBitmap: Loaded " + uri + ", Original: " + options.outWidth + "x" + options.outHeight +
			  ", Sampled to: " + bmp.getWidth() + "x" + bmp.getHeight() + " with inSampleSize=" + options.inSampleSize);
	  }
	  return bmp;
    } catch (FileNotFoundException fnfe) {
	  Log.e(TAG, "loadSampledThumbnailBitmap: File not found for URI: " + uri, fnfe);
	  return null;
    } catch (OutOfMemoryError oom) { // OOM 仍然可能发生，即使在加载缩略图时
	  Log.e(TAG, "loadSampledThumbnailBitmap: OOM for URI: " + uri + " while trying to load thumbnail", oom);
	  System.gc(); // 请求GC
	  return null;
    } catch (Exception e) { // 其他通用异常
	  Log.e(TAG, "loadSampledThumbnailBitmap: Generic error for URI: " + uri, e);
	  return null;
    } finally {
	  if (inputStream != null) {
		try { inputStream.close(); } catch (IOException ignore) {}
	  }
    }
  }
	
	
  /*
  private void loadThumbnailAsync(final ImageData data, final ImageView targetThumbView) {
    if (data == null || targetThumbView == null || data.originalUri == null) {
	  Log.w(TAG, "loadThumbnailAsync: Invalid input. dataNull=" + (data == null) + 
			", viewNull=" + (targetThumbView == null) + 
			", uriNull=" + (data != null && data.originalUri == null));
	  return;
    }

    if (data.thumbnail != null && !data.thumbnail.isRecycled()) {
	  // 在 loadThumbnailAsync 方法内部
// 第一个 mainHandler.post(() -> { ... }); 改为：
	  mainHandler.post(new Runnable() {
		  @Override
		  public void run() {
			if (targetThumbView.getWindowToken() != null) {
			  targetThumbView.setImageBitmap(data.thumbnail);
			}
		  }
		});

// executor.execute(() -> { ... }); 改为：
	  executor.execute(new Runnable() {
		  @Override
		  public void run() {
			final Bitmap thumb = loadSampledThumbnailBitmap(data.originalUri, THUMBNAIL_SIZE, THUMBNAIL_SIZE);
			// data.isLoadingThumb = false; // 移至UI线程回调

			// mainHandler.post(() -> { ... }); 改为：
			mainHandler.post(new Runnable() {
				@Override
				public void run() {
				  data.isLoadingThumb = false;
				  Object tagObj = targetThumbView.getTag();
				  if (tagObj instanceof Integer) {
                    int tag = (Integer) tagObj;
                    if (isValidIndex(tag) && selectedImages.size() > tag && selectedImages.get(tag) == data && targetThumbView.getWindowToken() != null) {
					  if (thumb != null) {
						data.thumbnail = thumb;
						targetThumbView.setImageBitmap(thumb);
					  } else {
						Log.w(TAG, "loadThumbnailAsync: Failed to load thumbnail bitmap for " + data.originalUri);
						targetThumbView.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
					  }
					  highlightThumbnail(currentlyDisplayedIndex);
                    } else {
					  if (DEBUG_IMAGE_LOADING) Log.d(TAG, "loadThumbnailAsync: View/Tag mismatch or image removed. Recycling loaded thumb (if any) for " + data.originalUri);
					  safeRecycle(thumb);
                    }
				  } else {
                    if (DEBUG_IMAGE_LOADING) Log.w(TAG, "loadThumbnailAsync: targetThumbView tag is not Integer or null. Recycling thumb (if any).");
                    safeRecycle(thumb);
				  }
				}
			  });
		  }
		});
  }
  }
  */
	
	
	private void loadThumbnailAsync(final ImageData data, final ImageView targetThumbView) {
		if (data == null || targetThumbView == null || data.originalUri == null)
			return;
		if (data.thumbnail != null && !data.thumbnail.isRecycled()) {
			mainHandler.post(new Runnable() {
				@Override
				public void run() {
					if (targetThumbView.getWindowToken() != null) {
						targetThumbView.setImageBitmap(data.thumbnail);
						targetThumbView.setBackgroundColor(Color.BLUE);
					}
				}
			});
			return;
		}
		if (data.isLoadingThumb)
			return;
		data.isLoadingThumb = true;
		targetThumbView.setImageResource(0);
		targetThumbView.setBackgroundColor(0xFFDDDDDD);
		executor.execute(new Runnable() {
			@Override
			public void run() {
				final Bitmap thumb = loadSampledBitmapFromUri(data.originalUri, THUMBNAIL_SIZE, THUMBNAIL_SIZE);
				data.isLoadingThumb = false;
				mainHandler.post(new Runnable() {
					@Override
					public void run() {
						Object tagObj = targetThumbView.getTag();
						if (tagObj instanceof Integer) {
							int tag = (Integer) tagObj;
							if (isValidIndex(tag) && selectedImages.size() > tag && selectedImages.get(tag) == data
									&& targetThumbView.getWindowToken() != null) {
								if (thumb != null) {
									data.thumbnail = thumb;
									targetThumbView.setImageBitmap(thumb);
									targetThumbView.setBackgroundColor(Color.TRANSPARENT);
								} else {
									targetThumbView.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
									targetThumbView.setBackgroundColor(Color.TRANSPARENT);
								}
								if (tag == currentlyDisplayedIndex)
									highlightThumbnail(currentlyDisplayedIndex);
							} else
								safeRecycle(thumb);
						} else {
							safeRecycle(thumb);
						}
					}
				});
			}
		});
	}

	private void switchToNextImage() {
		if (selectedImages.size() > 1) {
			currentlyDisplayedIndex = (currentlyDisplayedIndex + 1) % selectedImages.size();
			loadFullImageAsync(currentlyDisplayedIndex);
			scrollToThumbnail(currentlyDisplayedIndex);
		}
	}
	private void switchToPreviousImage() {
		if (selectedImages.size() > 1) {
			currentlyDisplayedIndex = (currentlyDisplayedIndex - 1 + selectedImages.size()) % selectedImages.size();
			loadFullImageAsync(currentlyDisplayedIndex);
			scrollToThumbnail(currentlyDisplayedIndex);
		}
	}

	private void scrollToThumbnail(final int index) {
		if (isValidIndex(index)) {
			final View tv = thumbnailLayout.getChildAt(index);
			if (tv != null)
				mainHandler.post(new Runnable() {
					@Override
					public void run() {
						thumbnailScrollView
								.smoothScrollTo(tv.getLeft() - (thumbnailScrollView.getWidth() - tv.getWidth()) / 2, 0);
					}
				});
		}
	}
/*
	private void highlightThumbnail(int selIdx) {
		for (int i = 0; i < thumbnailLayout.getChildCount(); i++) {
			View c = thumbnailLayout.getChildAt(i);
			if (c instanceof ImageView && c.getTag() instanceof Integer) {
				ImageView iv = (ImageView) c;
				int idx = ((Integer) c.getTag()).intValue();
				boolean isSelected = (idx == selIdx);
				iv.setAlpha(isSelected ? 1.0f : 0.6f);
				iv.setPadding(isSelected ? 4 : 0, isSelected ? 4 : 0, isSelected ? 4 : 0, isSelected ? 4 : 0);
				if (isSelected) {
					iv.setBackgroundColor(0xFF90CAF9);
				} else {
					if (iv.getDrawable() != null
							&& !(iv.getDrawable() instanceof android.graphics.drawable.ColorDrawable)) {
						iv.setBackgroundColor(Color.TRANSPARENT);
					}
				}
			}
		}
	}
*/

// 如果要在 dp 中定义边框宽度，则需要此辅助方法
  private int dpToPx(int dp) {
    return (int) (dp * getResources().getDisplayMetrics().density);
  }

  private void revertSingleImageAsync(final int indexToRevert) {
    if (!isValidIndex(indexToRevert)) return;

    final ImageData data = selectedImages.get(indexToRevert);
    if (data.originalUri == null) {
	  showBanner(("无法还原：未找到原始图片路径"),false);
	  return;
    }

    showLoading(true, getString(R.string.reverting_image));
    final long startTime = System.currentTimeMillis();

    executor.execute(new Runnable() {
        @Override
        public void run() {
		  // loadSampledBitmapFromUri 已经根据用户要求设置为 inSampleSize=1，会加载原始分辨率
		  final Bitmap originalBitmap = loadSampledBitmapFromUri(data.originalUri,
																 MAX_LOAD_DIMENSION, MAX_LOAD_DIMENSION); // reqWidth/Height 在 inSampleSize=1 时可能被忽略，但保留它们以保持一致性

		  mainHandler.post(new Runnable() {
			  @Override
			  public void run() {
				showLoading(false, null);
				if (originalBitmap != null) {
				  // 检查索引是否仍然有效并且是当前显示的图像
				  if (isValidIndex(indexToRevert) && currentlyDisplayedIndex == indexToRevert) {
					safeRecycle(data.currentBitmap); // 回收旧的 currentBitmap
					data.currentBitmap = originalBitmap; // 更新为新加载的原始图像

					// 尝试显示 (如果 ImageView 设置了 software layer type, 应该能处理大图)
					mainImageView.setImageBitmap(data.currentBitmap);
					updateInfoText(data.currentBitmap, System.currentTimeMillis() - startTime);
					showBanner("当前图片已还原",false);
				  } else {
					// 如果在加载过程中切换了图片，或者索引变得无效，则回收加载的位图
					safeRecycle(originalBitmap);
					if (!isValidIndex(indexToRevert)) {
					  showBanner(("还原失败：图片已不再选中。"),true);
					}
				  }
				} else {
				  showBanner(("还原失败：无法加载原始图片。"),true);
				  // 保持当前图像不变
				  if (isValidIndex(indexToRevert) && currentlyDisplayedIndex == indexToRevert) {
					updateInfoText(data.currentBitmap, -1); // 使用现有位图更新信息
				  }
				}
				updateButtonStates();
			  }
            });
        }
	  });
  }

  private void highlightThumbnail(int selIdx) {
    for (int i = 0; i < thumbnailLayout.getChildCount(); i++) {
	  View c = thumbnailLayout.getChildAt(i);
	  if (c instanceof ImageView && c.getTag() instanceof Integer) {
		ImageView iv = (ImageView) c;
		int idx = ((Integer) c.getTag()).intValue();
		boolean isSelected = (idx == selIdx);

		if (isSelected) {
		  iv.setAlpha(1.0f);
		  // 创建带边框的Drawable
		  android.graphics.drawable.GradientDrawable borderDrawable = new android.graphics.drawable.GradientDrawable();
		  borderDrawable.setColor(Color.TRANSPARENT); // 背景透明或半透明浅色
		  borderDrawable.setStroke(dpToPx(3), Color.BLUE); // 3dp 蓝色边框
		  iv.setBackground(borderDrawable);
		  iv.setPadding(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2)); // 边框内部的padding
		} else {
		  iv.setAlpha(0.6f);
		  iv.setPadding(0, 0, 0, 0); // 移除padding
		  // 恢复原始背景（如果图片已加载则透明，否则为占位符颜色）
		  Object tagObj = iv.getTag();
		  if (tagObj instanceof Integer) {
			int currentThumbIndex = (Integer) tagObj;
			if (isValidIndex(currentThumbIndex)) {
			  ImageData currentThumbData = selectedImages.get(currentThumbIndex);
			  // 如果缩略图存在且未回收，则背景透明
			  if (currentThumbData.thumbnail != null && !currentThumbData.thumbnail.isRecycled()) {
				iv.setBackgroundColor(Color.TRANSPARENT);
			  } else {
				// 否则，使用占位符背景色 (与 refreshThumbnailView 中设置的一致)
				iv.setBackgroundColor(0xFF363636);
			  }
			} else {
			  iv.setBackgroundColor(0xFF363636); // 默认占位符颜色
			}
		  } else {
			iv.setBackgroundColor(0xFF363636); // 默认占位符颜色
		  }
		}
	  }
    }
  }
  
  

// ...
/*
  private void loadFullImageAsync(final int index) {
    if (DEBUG_IMAGE_LOADING) {
	  Log.i(TAG, "loadFullImageAsync: CALLED for index=" + index +
			", currentDisplayed=" + currentlyDisplayedIndex +
			", totalSelected=" + selectedImages.size());
    }

    if (!isValidIndex(index)) {
	  if (DEBUG_IMAGE_LOADING) Log.w(TAG, "loadFullImageAsync: INVALID index=" + index + ". Clearing mainImageView.");
	  mainImageView.setImageDrawable(null);
	  highlightThumbnail(-1);
	  updateInfoText(null, -1);
	  updateButtonStates();
	  return;
    }

    final ImageData data = selectedImages.get(index);
    if (DEBUG_IMAGE_LOADING) Log.d(TAG, "loadFullImageAsync: Index " + index + ", URI: " + data.originalUri);

    if (data.isLoadingFull) {
	  if (DEBUG_IMAGE_LOADING) Log.d(TAG, "loadFullImageAsync: Image at index=" + index + " is ALREADY LOADING. URI: " + data.originalUri + ". Aborting new load.");
	  return;
    }

    // 如果当前显示的图片就是目标图片，并且其bitmap有效，则无需重新加载
    if (currentlyDisplayedIndex == index && data.currentBitmap != null && !data.currentBitmap.isRecycled()) {
	  if (DEBUG_IMAGE_LOADING) Log.d(TAG, "loadFullImageAsync: Image at index=" + index + " is current and bitmap is valid. Displaying. WxH: " + data.currentBitmap.getWidth() + "x" + data.currentBitmap.getHeight());
	  mainImageView.setImageBitmap(data.currentBitmap); // 确保ImageView更新
	  highlightThumbnail(index);
	  scrollToThumbnail(index);
	  updateButtonStates(); // 确保按钮状态正确
	  updateInfoText(data.currentBitmap, -1);
	  return;
    }

    // 如果目标索引不是当前显示的，或者当前显示的但bitmap无效，则需要加载
    if (DEBUG_IMAGE_LOADING) Log.d(TAG, "loadFullImageAsync: Image at index=" + index + " needs loading (or is current but bitmap invalid). Starting async load. URI: " + data.originalUri);

    data.isLoadingFull = true;
    showLoading(true, getString(R.string.loading_image));
    mainImageView.setImageDrawable(null); // 清空，准备加载新的
    updateInfoText(null, -1);
    // updateButtonStates(); // showLoading会调用
  
	// 示例：
// mainHandler.post(() -> showBanner(getString(R.string.out_of_memory_loading_image)));
// 改为：
	mainHandler.post(new Runnable() {
		@Override
		public void run() {
		  showBanner(getString(R.string.out_of_memory_loading_image));
		}
	  });
	}
*/
  
	private void loadFullImageAsync(final int index) {
		if (!isValidIndex(index)) {
			mainImageView.setImageDrawable(null);
			highlightThumbnail(-1);
			updateInfoText(null, -1);
			return;
		}
		final ImageData data = selectedImages.get(index);
		if (data.isLoadingFull)
			return;
		if (data.currentBitmap != null && !data.currentBitmap.isRecycled()) {
			mainImageView.setImageBitmap(data.currentBitmap);
			highlightThumbnail(index);
			scrollToThumbnail(index);
			updateButtonStates();
			updateInfoText(data.currentBitmap, -1);
			return;
		}
		data.isLoadingFull = true;
		showLoading(true, getString(R.string.loading_image));
		mainImageView.setImageDrawable(null);
		updateInfoText(null, -1);
		executor.execute(new Runnable() {
			@Override
			public void run() {
				final Bitmap fullBmp = loadSampledBitmapFromUri(data.originalUri, MAX_LOAD_DIMENSION,
						MAX_LOAD_DIMENSION);
				data.isLoadingFull = false;
				mainHandler.post(new Runnable() {
					@Override
					public void run() {
						showLoading(false, null);
						if (currentlyDisplayedIndex == index) {
							if (fullBmp != null) {
								safeRecycle(data.currentBitmap);
								data.currentBitmap = fullBmp;
								mainImageView.setImageBitmap(fullBmp);
								updateInfoText(fullBmp, -1);
							} else {
								mainImageView.setImageResource(android.R.drawable.ic_dialog_alert);
								safeRecycle(data.currentBitmap);
								data.currentBitmap = null;
								showBanner(getString(R.string.save_failed, getString(R.string.loading_failed_suffix)),true);
								updateInfoText(null, -1);
							}
							highlightThumbnail(index);
							scrollToThumbnail(index);
						} else
							safeRecycle(fullBmp);
						updateButtonStates();
					}
				});
			}
		});
	}

	
	private void processImageInternal(final boolean encryptMode) {
		if (!isValidIndex(currentlyDisplayedIndex)) {
			showBanner(getString(R.string.no_image_selected_for_action),true);
			return;
		}
		final int procIdx = currentlyDisplayedIndex;
		final ImageData data = selectedImages.get(procIdx);
		final Bitmap originalSrcBmp = data.currentBitmap;

		if (originalSrcBmp == null || originalSrcBmp.isRecycled()) {
			showBanner(getString(R.string.save_failed, getString(R.string.invalid_image_data_suffix)),true);
			return;
		}

		// Key validation part is important here, using currentAlgorithmMode
		String keyStr = "";
		double keyDbl = 0.0;
		boolean keyOk = true;
		if (currentAlgorithmMode.equals("pe1") || currentAlgorithmMode.equals("pe2")) {
			try {
				keyDbl = Double.parseDouble(keyDoubleEditText.getText().toString());
				if (keyDbl <= 0 || keyDbl >= 1) {
					keyOk = false;
					Log.w(TAG, "PE Key out of range: " + keyDbl);
				}
			} catch (NumberFormatException e) {
				keyOk = false;
				Log.w(TAG, "PE Key parse error", e);
			}
			if (!keyOk)
				showBanner(getString(R.string.key_hint_double),false);
		} else if (!currentAlgorithmMode.equals("gilbert")) { // Gilbert doesn't need key string
			keyStr = keyStringEditText.getText().toString();
			// Potentially add validation for keyStr if needed for other algorithms
		}
		if (!keyOk) // If key validation failed for PE
			return;

		b2InputWasPadded = false;
		Bitmap bmpToProcess = originalSrcBmp;
		Bitmap tempPaddedBmp = null;

		// Padding for 'b' mode
		if (currentAlgorithmMode.equals("b")) {
			int originalWidth = originalSrcBmp.getWidth();
			int originalHeight = originalSrcBmp.getHeight();
			int newWidth = originalWidth;
			int newHeight = originalHeight;

			if (originalWidth % DEFAULT_BLOCK_SIZE_X != 0) {
				newWidth = ((originalWidth / DEFAULT_BLOCK_SIZE_X) + 1) * DEFAULT_BLOCK_SIZE_X;
				b2InputWasPadded = true;
			}
			if (originalHeight % DEFAULT_BLOCK_SIZE_Y != 0) {
				newHeight = ((originalHeight / DEFAULT_BLOCK_SIZE_Y) + 1) * DEFAULT_BLOCK_SIZE_Y;
				b2InputWasPadded = true;
			}

			if (b2InputWasPadded) {
				Log.d(TAG, "B2 Padding: Original " + originalWidth + "x" + originalHeight + " -> Padded " + newWidth
						+ "x" + newHeight);
				try {
					tempPaddedBmp = Bitmap.createBitmap(newWidth, newHeight, originalSrcBmp.getConfig());
					Canvas canvas = new Canvas(tempPaddedBmp);
					canvas.drawBitmap(originalSrcBmp, 0, 0, null);
					bmpToProcess = tempPaddedBmp;
				} catch (OutOfMemoryError oom) {
					showBanner(getString(R.string.save_failed, getString(R.string.out_of_memory_suffix) + " (padding)"),true);
					safeRecycle(tempPaddedBmp);
					return;
				}
			}
		}

		final Bitmap finalBmpToProcess = bmpToProcess; // This is either originalSrcBmp or tempPaddedBmp
		final Bitmap resBmp;
		try {
			resBmp = finalBmpToProcess.copy(finalBmpToProcess.getConfig(), true); // Create a mutable copy for native processing
			if (resBmp == null)
				throw new OutOfMemoryError("Bitmap.copy returned null for result");
		} catch (OutOfMemoryError oom) {
			showBanner(getString(R.string.save_failed, getString(R.string.out_of_memory_suffix)),true);
			if (tempPaddedBmp != null && tempPaddedBmp != originalSrcBmp) { // Clean up padded if it was created and different
				safeRecycle(tempPaddedBmp);
			}
			return;
		}

		showLoading(true, getString(R.string.processing_image));
		final long startT = System.currentTimeMillis();
		final String finalKeyStr = keyStr;
		final double finalKeyDbl = keyDbl;
		final String modeToProcess = currentAlgorithmMode; // Capture current mode for the thread
		final Bitmap finalTempPaddedBmp = tempPaddedBmp; // For cleanup in handler

		executor.execute(new Runnable() {
			@Override
			public void run() {
				boolean success = false;
				String errMsg = null;
				long duration = -1;
				try {
					if (finalBmpToProcess.isRecycled())
						throw new IllegalStateException("Source bitmap for processing recycled unexpectedly");
					if (resBmp.isRecycled())
						throw new IllegalStateException("Result bitmap for processing recycled unexpectedly");

					Log.d(TAG, "Processing with mode: " + modeToProcess + ", KeyStr: '" + finalKeyStr + "', KeyDbl: "
							+ finalKeyDbl);
					if (modeToProcess.equals("gilbert")) {
						success = nativeProcessImage(finalBmpToProcess, resBmp, encryptMode);
					} else if (modeToProcess.equals("b")) {
						success = nativeProcessBlockScramble(finalBmpToProcess, resBmp, finalKeyStr,
								DEFAULT_BLOCK_SIZE_X, DEFAULT_BLOCK_SIZE_Y, encryptMode);
					} else if (modeToProcess.equals("c")) {
						success = nativeProcessPixelScramble(finalBmpToProcess, resBmp, finalKeyStr, encryptMode);
					} else if (modeToProcess.equals("c2")) {
						success = nativeProcessRowPixelScramble(finalBmpToProcess, resBmp, finalKeyStr, encryptMode);
					} else if (modeToProcess.equals("pe1")) {
						success = nativeProcessPE1(finalBmpToProcess, resBmp, finalKeyDbl, encryptMode);
					} else if (modeToProcess.equals("pe2")) {
						success = nativeProcessPE2(finalBmpToProcess, resBmp, finalKeyDbl, encryptMode);
					} else {
						errMsg = getString(R.string.unknown_mode_error_prefix) + modeToProcess;
						success = false;
						Log.e(TAG, errMsg);
					}

					if (success)
						duration = System.currentTimeMillis() - startT;
				} catch (UnsatisfiedLinkError ule) {
					errMsg = getString(R.string.save_failed, getString(R.string.native_library_error_suffix));
					success = false;
					Log.e(TAG, "Native method link error", ule);
				} catch (Exception e) {
					errMsg = getString(R.string.save_failed, getString(R.string.processing_error_suffix)) + ": "
							+ e.getMessage();
					Log.e(TAG, "Processing exception", e);
					success = false;
				}

				final boolean finalSuccess = success;
				final String finalErrMsg = errMsg;
				final long finalDuration = duration;

				mainHandler.post(new Runnable() {
					@Override
					public void run() {
						showLoading(false, null);
						// Check if the processed image is still the one being displayed
						if (isValidIndex(currentlyDisplayedIndex) && currentlyDisplayedIndex == procIdx) {
							if (finalSuccess) {
								// originalSrcBmp is the bitmap that was in data.currentBitmap before processing
								// If originalSrcBmp was padded, finalTempPaddedBmp holds that padded version.
								// finalBmpToProcess was the (possibly padded) input to native code.
								// resBmp is the output from native code.

								// Recycle the original bitmap that was in data.currentBitmap ONLY IF it's not the same as resBmp.
								// This happens if originalSrcBmp was not padded, so finalBmpToProcess == originalSrcBmp.
								// Or if originalSrcBmp was padded, then finalBmpToProcess == finalTempPaddedBmp.
								if (originalSrcBmp != resBmp && originalSrcBmp != null
										&& !originalSrcBmp.isRecycled()) {
									safeRecycle(originalSrcBmp);
								}

								data.currentBitmap = resBmp; // Store the processed bitmap
								mainImageView.setImageBitmap(resBmp);
								showBanner(getString(R.string.current_image_option)+"已"+ (encryptMode
										? getString(R.string.obfuscated_suffix)
										: getString(R.string.deobfuscated_suffix)),false);
								updateInfoText(resBmp, finalDuration);
							} else {
								// Processing failed, recycle the resBmp (which was a copy)
								safeRecycle(resBmp);
								showBanner(finalErrMsg != null
										? finalErrMsg
										: getString(R.string.save_failed, getString(R.string.unknown_error_suffix)),true);
								// Ensure originalSrcBmp is still displayed or reloaded if it got corrupted
								// If originalSrcBmp is still valid, update info text with it.
								if (originalSrcBmp != null && !originalSrcBmp.isRecycled()) {
									mainImageView.setImageBitmap(originalSrcBmp); // Restore original on failure if possible
									updateInfoText(originalSrcBmp, -1);
								} else if (finalBmpToProcess != null && !finalBmpToProcess.isRecycled()
										&& finalBmpToProcess != finalTempPaddedBmp) {
									// This case should not happen often, implies originalSrcBmp became invalid
									// but the input to processing (non-padded) is still ok.
									mainImageView.setImageBitmap(finalBmpToProcess);
									updateInfoText(finalBmpToProcess, -1);
								} else {
									// Fallback, if original is also bad
									mainImageView.setImageResource(android.R.drawable.ic_dialog_alert);
									updateInfoText(null, -1);
								}
							}
							updateButtonStates();
						} else {
							// Displayed image changed during processing, discard result
							safeRecycle(resBmp);
						}

						// Clean up the temporary padded bitmap if it was created and is not the current bitmap
						if (finalTempPaddedBmp != null && finalTempPaddedBmp != data.currentBitmap) {
							safeRecycle(finalTempPaddedBmp);
						}
					}
				});
			}
		});
	}

	private void processAllImagesAsync(final boolean encryptMode) {
		if (selectedImages.isEmpty()) {
			showBanner(getString(R.string.no_image_selected_for_action),true);
			return;
		}
		final String procModeForAll = currentAlgorithmMode; // Capture current mode for the entire batch
		String keyStr = "";
		double keyDbl = 0.0;
		boolean keyOk = true;

		if (procModeForAll.equals("pe1") || procModeForAll.equals("pe2")) {
			try {
				keyDbl = Double.parseDouble(keyDoubleEditText.getText().toString());
				if (keyDbl <= 0 || keyDbl >= 1) {
					keyOk = false;
					Log.w(TAG, "PE Key out of range for all: " + keyDbl);
				}
			} catch (Exception e) {
				keyOk = false;
				Log.w(TAG, "PE Key parse error for all", e);
			}
		} else if (!procModeForAll.equals("gilbert")) {
			keyStr = keyStringEditText.getText().toString();
		}
		if (!keyOk) {
			showBanner(getString(R.string.invalid_key_cannot_process_all_message),true);
			return;
		}

		final int total = selectedImages.size();
		final AtomicInteger procCnt = new AtomicInteger(0);
		final AtomicInteger succCnt = new AtomicInteger(0);
		final StringBuilder errors = new StringBuilder();
		final String fKeyStr = keyStr;
		final double fKeyDbl = keyDbl;
		showLoading(true, String.format(Locale.CHINA, getString(R.string.preparing_to_process_format), 1, total));
		final long batchStartTime = System.currentTimeMillis();

		executor.execute(new Runnable() {
			@Override
			public void run() {
				for (int i = 0; i < total; i++) {
					final int curIdx = i;
					mainHandler.post(new Runnable() {
						@Override
						public void run() {
							if (progressBar.getVisibility() == View.VISIBLE)
								showLoading(true, String.format(Locale.CHINA, getString(R.string.processing_format),
										curIdx + 1, total));
						}
					});

					if (!isValidIndex(curIdx)) {
						procCnt.incrementAndGet();
						continue;
					}
					final ImageData data = selectedImages.get(curIdx);
					Bitmap bitmapFromImageData = data.currentBitmap;
					Bitmap loadedFreshBitmap = null; // If we need to load from URI
					Bitmap sourceForProcessingThisImage; // The bitmap that will be input (original or fresh load)

					Bitmap bmpToActuallyProcessNative = null; // This might be a padded version
					Bitmap tempPaddedVersionThisLoop = null;
					Bitmap resultBitmapForThisImage = null; // Output of native call
					boolean currentImageSuccess = false;

					try {
						// 1. Get a source bitmap
						if (bitmapFromImageData != null && !bitmapFromImageData.isRecycled()) {
							sourceForProcessingThisImage = bitmapFromImageData;
						} else {
							loadedFreshBitmap = loadSampledBitmapFromUri(data.originalUri, MAX_LOAD_DIMENSION,
									MAX_LOAD_DIMENSION);
							sourceForProcessingThisImage = loadedFreshBitmap;
						}

						if (sourceForProcessingThisImage == null || sourceForProcessingThisImage.isRecycled()) {
							throw new IOException(getString(R.string.cannot_load_source_image_format, curIdx + 1));
						}

						// 2. Prepare for native processing (padding if 'b' mode)
						bmpToActuallyProcessNative = sourceForProcessingThisImage; // Default
						boolean wasPaddedThisLoop = false;

						if (procModeForAll.equals("b")) {
							int originalW = sourceForProcessingThisImage.getWidth();
							int originalH = sourceForProcessingThisImage.getHeight();
							int newW = originalW, newH = originalH;
							if (originalW % DEFAULT_BLOCK_SIZE_X != 0) {
								newW = ((originalW / DEFAULT_BLOCK_SIZE_X) + 1) * DEFAULT_BLOCK_SIZE_X;
								wasPaddedThisLoop = true;
							}
							if (originalH % DEFAULT_BLOCK_SIZE_Y != 0) {
								newH = ((originalH / DEFAULT_BLOCK_SIZE_Y) + 1) * DEFAULT_BLOCK_SIZE_Y;
								wasPaddedThisLoop = true;
							}

							if (wasPaddedThisLoop) {
								tempPaddedVersionThisLoop = Bitmap.createBitmap(newW, newH,
										sourceForProcessingThisImage.getConfig());
								Canvas canvas = new Canvas(tempPaddedVersionThisLoop);
								canvas.drawBitmap(sourceForProcessingThisImage, 0, 0, null);
								bmpToActuallyProcessNative = tempPaddedVersionThisLoop;
							}
						}

						// 3. Create mutable copy for native processing output
						resultBitmapForThisImage = bmpToActuallyProcessNative
								.copy(bmpToActuallyProcessNative.getConfig(), true);
						if (resultBitmapForThisImage == null)
							throw new OutOfMemoryError("Bitmap.copy failed for result in batch");

						// 4. Native processing
						Log.d(TAG, "Batch Proc [" + (curIdx + 1) + "] Mode: " + procModeForAll);
						if (procModeForAll.equals("gilbert")) {
							currentImageSuccess = nativeProcessImage(bmpToActuallyProcessNative,
									resultBitmapForThisImage, encryptMode);
						} else if (procModeForAll.equals("b")) {
							currentImageSuccess = nativeProcessBlockScramble(bmpToActuallyProcessNative,
									resultBitmapForThisImage, fKeyStr, DEFAULT_BLOCK_SIZE_X, DEFAULT_BLOCK_SIZE_Y,
									encryptMode);
						} else if (procModeForAll.equals("c")) {
							currentImageSuccess = nativeProcessPixelScramble(bmpToActuallyProcessNative,
									resultBitmapForThisImage, fKeyStr, encryptMode);
						} else if (procModeForAll.equals("c2")) {
							currentImageSuccess = nativeProcessRowPixelScramble(bmpToActuallyProcessNative,
									resultBitmapForThisImage, fKeyStr, encryptMode);
						} else if (procModeForAll.equals("pe1")) {
							currentImageSuccess = nativeProcessPE1(bmpToActuallyProcessNative, resultBitmapForThisImage,
									fKeyDbl, encryptMode);
						} else if (procModeForAll.equals("pe2")) {
							currentImageSuccess = nativeProcessPE2(bmpToActuallyProcessNative, resultBitmapForThisImage,
									fKeyDbl, encryptMode);
						} else {
							throw new Exception(getString(R.string.unknown_mode_error_prefix) + " " + procModeForAll);
						}

						if (!currentImageSuccess)
							throw new Exception(
									getString(R.string.native_library_processing_failed_format, curIdx + 1));

						// 5. Success: Update ImageData and recycle old bitmaps
						// Recycle original bitmap from ImageData if it's different from the new result
						if (bitmapFromImageData != null && bitmapFromImageData != resultBitmapForThisImage) {
							safeRecycle(bitmapFromImageData);
						}
						// If we loaded a fresh bitmap and it's different from the new result (should always be true if loadedFreshBitmap exists)
						if (loadedFreshBitmap != null && loadedFreshBitmap != resultBitmapForThisImage) {
							safeRecycle(loadedFreshBitmap);
						}

						data.currentBitmap = resultBitmapForThisImage; // Store the new processed bitmap
						succCnt.incrementAndGet();
						resultBitmapForThisImage = null; // Ownership transferred to data.currentBitmap

					} catch (OutOfMemoryError oom) {
						errors.append(
								String.format(Locale.CHINA, getString(R.string.image_out_of_memory_format), curIdx + 1))
								.append("\n");
						Log.e(TAG, "OOM in batch processing for image " + curIdx, oom);
						safeRecycle(resultBitmapForThisImage); // Recycle if processing failed here
					} catch (Exception e) {
						errors.append(String.format(Locale.CHINA, getString(R.string.image_error_format), curIdx + 1,
								e.getMessage())).append("\n");
						Log.e(TAG, "Error in batch processing for image " + curIdx, e);
						safeRecycle(resultBitmapForThisImage); // Recycle if processing failed here
					} finally {
						// Clean up bitmaps that are not data.currentBitmap
						// loadedFreshBitmap might still exist if sourceForProcessingThisImage was from data.currentBitmap and processing failed
						if (loadedFreshBitmap != null && loadedFreshBitmap != data.currentBitmap) {
							safeRecycle(loadedFreshBitmap);
						}
						// tempPaddedVersionThisLoop might still exist if padding occurred and processing failed or if source was not padded
						if (tempPaddedVersionThisLoop != null && tempPaddedVersionThisLoop != data.currentBitmap) {
							safeRecycle(tempPaddedVersionThisLoop);
						}
						procCnt.incrementAndGet();
					}
				}
				final long totalBatchDuration = System.currentTimeMillis() - batchStartTime;
				mainHandler.post(new Runnable() {
					@Override
					public void run() {
						showLoading(false, null);
						String summary = String.format(Locale.CHINA,
								getString(R.string.processing_summary_success_format), succCnt.get(), total);
						if (errors.length() > 0)
							summary += "\n" + getString(R.string.errors_prefix) + "\n" + errors.toString().trim();
						showBanner(summary,false);

						if (isValidIndex(currentlyDisplayedIndex)) {
							Bitmap curDispBmp = selectedImages.get(currentlyDisplayedIndex).currentBitmap;
							if (curDispBmp != null && !curDispBmp.isRecycled())
								mainImageView.setImageBitmap(curDispBmp);
							else { // If current displayed became null (e.g. OOM during its processing)
								mainImageView.setImageResource(android.R.drawable.ic_dialog_alert);
								if (isValidIndex(currentlyDisplayedIndex)) // Attempt to reload
									loadFullImageAsync(currentlyDisplayedIndex);
							}
							updateInfoText(curDispBmp, totalBatchDuration);
						} else
							updateInfoText(null, -1); // No image selected or list empty after processing
						updateButtonStates();
						refreshThumbnailView(); // Thumbnails might need update if bitmaps changed
					}
				});
			}
		});
	}

	private void revertAllImagesAsync() {
		if (selectedImages.isEmpty()) {
			showBanner(getString(R.string.no_image_selected_for_action),true);
			return;
		}
		final int total = selectedImages.size();
		final AtomicInteger revCnt = new AtomicInteger(0);
		final AtomicInteger succCnt = new AtomicInteger(0);
		final StringBuilder errors = new StringBuilder();
		showLoading(true, String.format(Locale.CHINA, getString(R.string.preparing_to_revert_format), 1, total));
		final long startT = System.currentTimeMillis();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				for (int i = 0; i < total; i++) {
					final int curIdx = i;
					mainHandler.post(new Runnable() {
						@Override
						public void run() {
							if (progressBar.getVisibility() == View.VISIBLE)
								showLoading(true, String.format(Locale.CHINA, getString(R.string.reverting_format),
										curIdx + 1, total));
						}
					});
					if (!isValidIndex(curIdx)) {
						revCnt.incrementAndGet();
						continue;
					}
					final ImageData data = selectedImages.get(curIdx);
					Bitmap origBmp = null;
					try {
						if (data.originalUri == null)
							throw new Exception(getString(R.string.no_original_uri_error));
						origBmp = loadSampledBitmapFromUri(data.originalUri, MAX_LOAD_DIMENSION, MAX_LOAD_DIMENSION);
						if (origBmp == null)
							throw new IOException(getString(R.string.cannot_load_original_image_error));

						Bitmap oldCurrentBitmap = data.currentBitmap; // Get ref to old bitmap
						data.currentBitmap = origBmp; // Assign new original bitmap

						// Recycle the old currentBitmap IF it's different from the newly loaded origBmp
						// and it's not already recycled.
						if (oldCurrentBitmap != null && oldCurrentBitmap != data.currentBitmap
								&& !oldCurrentBitmap.isRecycled()) {
							oldCurrentBitmap.recycle();
						}
						succCnt.incrementAndGet();
						origBmp = null; // Ownership transferred to data.currentBitmap
					} catch (OutOfMemoryError oom) {
						errors.append(
								String.format(Locale.CHINA, getString(R.string.image_out_of_memory_format), curIdx + 1))
								.append("\n");
						safeRecycle(origBmp); // Recycle if OOM occurred during load/assignment
					} catch (Exception e) {
						errors.append(String.format(Locale.CHINA, getString(R.string.image_error_format), curIdx + 1,
								e.getMessage())).append("\n");
						safeRecycle(origBmp); // Recycle if any other error
					} finally {
						revCnt.incrementAndGet();
					}
				}
				final long totalDur = System.currentTimeMillis() - startT;
				mainHandler.post(new Runnable() {
					@Override
					public void run() {
						showLoading(false, null);
						String summary = String.format(Locale.CHINA, getString(R.string.revert_summary_success),
								succCnt.get(), total);
						if (errors.length() > 0)
							summary += "\n" + getString(R.string.errors_prefix) + "\n" + errors.toString().trim();
						showBanner(summary,false);

						if (isValidIndex(currentlyDisplayedIndex)) {
							Bitmap curDispBmp = selectedImages.get(currentlyDisplayedIndex).currentBitmap;
							if (curDispBmp != null && !curDispBmp.isRecycled())
								mainImageView.setImageBitmap(curDispBmp);
							else { // If current became null (e.g. OOM during its revert)
								mainImageView.setImageResource(android.R.drawable.ic_dialog_alert);
								if (isValidIndex(currentlyDisplayedIndex))
									loadFullImageAsync(currentlyDisplayedIndex); // Attempt reload
							}
							updateInfoText(curDispBmp, totalDur);
						} else {
							updateInfoText(null, -1);
						}
						updateButtonStates();
						refreshThumbnailView(); // Thumbnails may need to be updated
					}
				});
			}
		});
	}

	private void confirmRemoveImage(final int indexToRemove) {
		if (!isValidIndex(indexToRemove))
			return;
		new AlertDialog.Builder(this).setTitle(R.string.confirm_remove_title)
				.setMessage(R.string.confirm_remove_message)
				.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface d, int w) {
						removeImageAt(indexToRemove);
					}
				}).setNegativeButton(R.string.no, null).show();
	}

	private void RemoveImageFormButton(final int indexToRemove) {
		if (!isValidIndex(indexToRemove))
			return;
		removeImageAt(indexToRemove);
	}

	private void confirmRemoveImageBigImage(final int indexToRemove) {
		if (!isValidIndex(indexToRemove))
			return;
		removeImageAt(indexToRemove);
	}

	private void removeImageAt(int indexToRemove) {
		if (!isValidIndex(indexToRemove))
			return;
		ImageData removed = selectedImages.remove(indexToRemove);
		safeRecycle(removed.thumbnail);
		safeRecycle(removed.currentBitmap);
		if (selectedImages.isEmpty()) {
			currentlyDisplayedIndex = -1;
			mainImageView.setImageDrawable(null);
			updateInfoText(null, -1);
		} else {
			if (currentlyDisplayedIndex >= selectedImages.size()) // If last element was removed
				currentlyDisplayedIndex = selectedImages.size() - 1;
			else if (currentlyDisplayedIndex > indexToRemove) // If removed before current
				currentlyDisplayedIndex--;
			// If currentlyDisplayedIndex == indexToRemove, and list is not empty,
			// it will either stay 0 if it was 0, or be adjusted if it was > 0 and items shifted.
			// A simple re-validation or setting to 0 if it becomes invalid is good.
			if (currentlyDisplayedIndex == indexToRemove && !selectedImages.isEmpty()) {
				currentlyDisplayedIndex = 0; // Default to first image
			} else if (currentlyDisplayedIndex >= selectedImages.size()) { // Final check
				currentlyDisplayedIndex = selectedImages.size() - 1;
			}

		}

		updateUiVisibility();
		updateStatusText();
		refreshThumbnailView();
		if (isValidIndex(currentlyDisplayedIndex))
			loadFullImageAsync(currentlyDisplayedIndex);
		else if (!selectedImages.isEmpty()) { // If list not empty but current index became invalid
			currentlyDisplayedIndex = 0; // Default to first
			loadFullImageAsync(currentlyDisplayedIndex);
		} else { // List is empty
			mainImageView.setImageDrawable(null);
			updateInfoText(null, -1);
		}
		updateButtonStates();
	}

	private void confirmClearAll() {
		if (selectedImages.isEmpty())
			return;
		new AlertDialog.Builder(this).setTitle(R.string.confirm_clear_title).setMessage(R.string.confirm_clear_message)
				.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface d, int w) {
						clearAllImages();
					}
				}).setNegativeButton(R.string.no, null).show();
	}

	private void clearAllImages() {
		for (ImageData data : selectedImages) {
			safeRecycle(data.thumbnail);
			safeRecycle(data.currentBitmap);
		}
		selectedImages.clear();
		thumbnailLayout.removeAllViews(); // Clear thumbnails
		addThumbnailAddButton(); // Re-add the "+" button to thumbnail scroll
		mainImageView.setImageDrawable(null);
		currentlyDisplayedIndex = -1;
		updateUiVisibility();
		updateStatusText();
		updateInfoText(null, -1);
		updateButtonStates();
	}

	// generateSaveFileName: This method should ONLY generate the base name, without extension.
	// The extension will be determined and appended in saveImageInternal.
	private String generateSaveFileName(String originalNameSuffix) {
		@SuppressLint("SimpleDateFormat")
		String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());

		String algorithmDisplayName = "未知算法";
		int selectedAlgoPosition = -1;
		if (algorithmSpinner != null) {
			selectedAlgoPosition = algorithmSpinner.getSelectedItemPosition();
		} else {
			Log.e(TAG, "generateSaveFileName: algorithmSpinner is null!");
			algorithmDisplayName = currentAlgorithmMode;
		}

		if (selectedAlgoPosition != -1) {
			try {
				String[] algorithmDisplayNames = getResources().getStringArray(R.array.algorithm_modes);
				if (selectedAlgoPosition >= 0 && selectedAlgoPosition < algorithmDisplayNames.length) {
					algorithmDisplayName = algorithmDisplayNames[selectedAlgoPosition];
					algorithmDisplayName = algorithmDisplayName.replaceAll("\\s*\\(.*\\)\\s*$", "").trim();
				} else {
					Log.w(TAG, "generateSaveFileName: selectedAlgoPosition out of bounds for algorithm_modes.");
					algorithmDisplayName = currentAlgorithmMode;
				}
			} catch (Resources.NotFoundException e) {
				Log.e(TAG, "R.array.algorithm_modes not found for filename generation", e);
				algorithmDisplayName = currentAlgorithmMode;
			}
		}

		String keyPart = "";
		// currentAlgorithmMode is used here because it's the internal reliable ID
		if (currentAlgorithmMode.equals("pe1") || currentAlgorithmMode.equals("pe2")) {
			try {
				if (keyDoubleEditText != null && keyDoubleEditText.getText() != null) {
					String keyDoubleStr = keyDoubleEditText.getText().toString();
					if (!keyDoubleStr.isEmpty()) {
						Double.parseDouble(keyDoubleStr);
						keyPart = "_密钥" + keyDoubleStr;
					} else {
						// keyPart = "_密钥空D"; // Let's keep it empty if no key
					}
				} else {
					// keyPart = "_密钥错误DInputNull";
				}
			} catch (NumberFormatException e) {
				// keyPart = "_密钥格式错误D"; 
				Log.w(TAG,
						"Invalid double key format for filename: "
								+ (keyDoubleEditText != null && keyDoubleEditText.getText() != null
										? keyDoubleEditText.getText().toString()
										: "null_input"));
			}
		} else if (!currentAlgorithmMode.equals("gilbert")) {
			if (keyStringEditText != null && keyStringEditText.getText() != null) {
				String rawKey = keyStringEditText.getText().toString();
				if (!rawKey.isEmpty()) {
					String sanitizedKey = rawKey;
					if (sanitizedKey.length() > 15) {
						sanitizedKey = sanitizedKey.substring(0, 15);
					}
					keyPart = "_密钥" + sanitizedKey;
				} else {
					// keyPart = "_无密钥S"; // Let's keep it empty if no key
				}
			} else {
				// keyPart = "_密钥错误SInputNull";
			}
		}

		String baseFileName = algorithmDisplayName + keyPart + "_" + ts
				+ (originalNameSuffix != null ? originalNameSuffix : "");

		baseFileName = baseFileName.replaceAll("[\\\\/:*?\"<>|]", "_");
		baseFileName = baseFileName.replaceAll("\\s+", "_");
		baseFileName = baseFileName.replaceAll("_+", "_");
		baseFileName = baseFileName.replaceAll("^_|_$", "");

		if (baseFileName.endsWith(".")) {
			baseFileName = baseFileName.substring(0, baseFileName.length() - 1) + "_";
		}
		if (baseFileName.isEmpty()) {
			baseFileName = "ProcessedImage_" + ts;
		}

		Log.d(TAG, "Generated save base filename: " + baseFileName);
		return baseFileName; // Return base name WITHOUT extension
	}

	private void checkWritePermissionAndSaveImage() {
		if (!isValidIndex(currentlyDisplayedIndex)) {
			showBanner(getString(R.string.no_image_selected_for_action),true);
			return;
		}
		final ImageData data = selectedImages.get(currentlyDisplayedIndex);
		if (data.currentBitmap == null || data.currentBitmap.isRecycled()) {
			showBanner(getString(R.string.save_failed, getString(R.string.no_valid_image_to_save_suffix)),true);
			return;
		}

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
			if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
				requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
						PERMISSION_REQUEST_WRITE_STORAGE);
				showBanner(getString(R.string.write_permission_denied) + " "
						+ getString(R.string.grant_permission_and_retry_save_message),true);
				return;
			}
		}
		// Pass null for nameSuffix as generateSaveFileName will handle timestamp and algo
		saveImage(data.currentBitmap, null);
	}

	// This method now only generates the base name and calls saveImageInternal.
	// The actual filename with extension is determined in saveImageInternal.
	private void saveImage(final Bitmap bitmapToSave, final String nameSuffix) {
		if (bitmapToSave == null || bitmapToSave.isRecycled()) {
			showBanner(getString(R.string.save_failed, getString(R.string.no_valid_image_data_suffix)),true);
			return;
		}

		showLoading(true, getString(R.string.saving_image));
		// baseName will NOT have an extension.
		final String baseName = generateSaveFileName(nameSuffix);

		executor.execute(new Runnable() {
			@Override
			public void run() {
				// saveImageInternal will determine the extension and full filename
				final Uri savedUri = saveImageInternal(bitmapToSave, baseName, currentAlgorithmMode); // Pass currentAlgorithmMode
				final String msg;
				if (savedUri != null) {
					// Determine the correct extension for the toast message
					String actualFileExtension = "gilbert".equals(currentAlgorithmMode) ? ".jpg" : ".png";
					String fullFileNameForToast = baseName + actualFileExtension;

					String pathHint = "";
					String appNameFolder = getString(R.string.app_name);
					if (appNameFolder == null || appNameFolder.trim().isEmpty())
						appNameFolder = "ImageProcessingApp";

					if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
						pathHint = " " + getString(R.string.at_location_prefix) + " " + Environment.DIRECTORY_PICTURES
								+ "/" + appNameFolder;
					} else {
						pathHint = " " + getString(R.string.at_location_prefix) + " " + Environment.DIRECTORY_PICTURES
								+ (appNameFolder.isEmpty() ? "" : "/" + appNameFolder);
					}
					msg = getString(R.string.save_success_filename, fullFileNameForToast) + pathHint;
				} else {
					msg = getString(R.string.save_failed, getString(R.string.operation_failed_suffix));
				}
				mainHandler.post(new Runnable() {
					@Override
					public void run() {
						showLoading(false, null);
						showBanner(msg,false);
						updateButtonStates();
					}
				});
			}
		});
	}

	private void checkWritePermissionAndSaveAllImages() {
		if (selectedImages.isEmpty()) {
			showBanner(getString(R.string.no_image_selected_for_action),true);
			return;
		}
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
			if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
				requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
						PERMISSION_REQUEST_WRITE_STORAGE);
				showBanner(getString(R.string.write_permission_denied) + " "
						+ getString(R.string.grant_permission_and_retry_save_all_message),true);
				return;
			}
		}
		saveAllImagesAsync();
	}

	private void saveAllImagesAsync() {
		if (selectedImages.isEmpty()) {
			showBanner(getString(R.string.no_image_selected_for_action),true);
			return;
		}
		final int total = selectedImages.size();
		final AtomicInteger savedCnt = new AtomicInteger(0);
		final StringBuilder errors = new StringBuilder();
		showLoading(true, String.format(Locale.CHINA, getString(R.string.preparing_to_save_format), 1, total));

		// Capture algorithm mode and keys at the START of the batch operation
		// This ensures all images in the batch are saved with the same settings.
		final String algorithmForBatchSave = currentAlgorithmMode;
		final String keyStringForBatch = (keyStringEditText != null && keyStringEditText.getText() != null)
				? keyStringEditText.getText().toString()
				: "";
		final String keyDoubleStringForBatch = (keyDoubleEditText != null && keyDoubleEditText.getText() != null)
				? keyDoubleEditText.getText().toString()
				: "0.0"; // Default for parsing if empty, though PE logic should handle empty

		executor.execute(new Runnable() {
			@Override
			public void run() {
				for (int i = 0; i < total; i++) {
					final int curIdx = i;
					mainHandler.post(new Runnable() {
						@Override
						public void run() {
							if (progressBar.getVisibility() == View.VISIBLE)
								showLoading(true, String.format(Locale.CHINA, getString(R.string.saving_format),
										curIdx + 1, total));
						}
					});
					if (!isValidIndex(curIdx)) {
						errors.append("索引无效: ").append(curIdx).append("\n");
						continue;
					}
					final ImageData data = selectedImages.get(curIdx);
					Bitmap bmpToSave = null;
					boolean recycleBmpAfterSave = false; // If we load it fresh just for saving
					try {
						if (data.currentBitmap != null && !data.currentBitmap.isRecycled())
							bmpToSave = data.currentBitmap;
						else { // If currentBitmap is null or recycled, try loading from original URI
							bmpToSave = loadSampledBitmapFromUri(data.originalUri, MAX_LOAD_DIMENSION,
									MAX_LOAD_DIMENSION);
							recycleBmpAfterSave = (bmpToSave != null); // Mark for recycling if loaded fresh
						}

						if (bmpToSave == null || bmpToSave.isRecycled())
							throw new IOException(getString(R.string.cannot_load_image_for_saving_format, curIdx + 1));

						// Generate a base name for this specific image in the batch
						// This uses the captured algorithmForBatchSave and keys for consistency
						@SuppressLint("SimpleDateFormat")
						String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
						String keyPart = ""; // Default no key part

						// Use algorithmForBatchSave and corresponding key strings for naming
						if (algorithmForBatchSave.equals("pe1") || algorithmForBatchSave.equals("pe2")) {
							if (!keyDoubleStringForBatch.isEmpty()) {
								try {
									double keyDblVal = Double.parseDouble(keyDoubleStringForBatch); // Validate
									keyPart = "_密钥" + keyDoubleStringForBatch;
								} catch (NumberFormatException nfe) {
									keyPart = "_密钥格式错误D";
								}
							}
						} else if (!algorithmForBatchSave.equals("gilbert")) {
							if (!keyStringForBatch.isEmpty()) {
								String sanitizedKey = keyStringForBatch
										.replaceAll("[^a-zA-Z0-9\\u4e00-\\u9fa5_\\-]", "").trim();
								if (sanitizedKey.length() > 15)
									sanitizedKey = sanitizedKey.substring(0, 15);
								if (!sanitizedKey.isEmpty())
									keyPart = "_密钥" + sanitizedKey;
							}
						}

						String algorithmDisplayNameForFile = algorithmForBatchSave; // Default to internal name
						try {
							String[] displayNames = getResources().getStringArray(R.array.algorithm_modes);
							String[] valueNames = getResources().getStringArray(R.array.algorithm_values);
							for (int j = 0; j < valueNames.length; j++) {
								if (valueNames[j].equals(algorithmForBatchSave) && j < displayNames.length) {
									algorithmDisplayNameForFile = displayNames[j].replaceAll("\\s*\\(.*\\)\\s*$", "")
											.trim();
									break;
								}
							}
						} catch (Exception e) {
							Log.w(TAG, "Could not get display name for batch save filename part");
						}

						String baseNameForThisImage = algorithmDisplayNameForFile + keyPart + "_" + ts
								+ String.format(Locale.US, "_img%03d", curIdx + 1);

						baseNameForThisImage = baseNameForThisImage.replaceAll("[\\\\/:*?\"<>|]", "_")
								.replaceAll("\\s+", "_").replaceAll("_+", "_").replaceAll("^_|_$", "");
						if (baseNameForThisImage.isEmpty())
							baseNameForThisImage = "ImageBatch_" + ts + String.format(Locale.US, "_%03d", curIdx + 1);

						// saveImageInternal will append the correct extension based on algorithmForBatchSave
						Uri savedUri = saveImageInternal(bmpToSave, baseNameForThisImage, algorithmForBatchSave);
						if (savedUri == null)
							throw new IOException(getString(R.string.image_save_failed_format, curIdx + 1));
						savedCnt.incrementAndGet();

					} catch (OutOfMemoryError oom) {
						errors.append(
								String.format(Locale.CHINA, getString(R.string.image_out_of_memory_format), curIdx + 1))
								.append("\n");
					} catch (Exception e) {
						errors.append(getString(R.string.save_failed, String.format(Locale.CHINA,
								getString(R.string.image_error_format), curIdx + 1, e.getMessage()))).append("\n");
					} finally {
						if (recycleBmpAfterSave && bmpToSave != null) // Recycle if we loaded it fresh
							safeRecycle(bmpToSave);
					}
				}
				mainHandler.post(new Runnable() {
					@Override
					public void run() {
						showLoading(false, null);
						String summary = String.format(Locale.CHINA, getString(R.string.save_summary_success_format),
								savedCnt.get(), total);
						if (errors.length() > 0)
							summary += "\n" + getString(R.string.errors_prefix) + "\n" + errors.toString().trim();
						showBanner(summary,false);
						updateButtonStates();
					}
				});
			}
		});
	}

	// Modified saveImageInternal to accept algorithmMode to determine format
	private Uri saveImageInternal(final Bitmap bitmapToSave, String baseName, String algorithmMode) {
		if (bitmapToSave == null || bitmapToSave.isRecycled())
			return null;

		ContentResolver resolver = getContentResolver();
		ContentValues values = new ContentValues();
		Uri imageCollection;

		// Determine format, extension, MIME type, and quality based on algorithmMode
		final boolean isGilbert = "gilbert".equals(algorithmMode);
		Bitmap.CompressFormat compressFormat = isGilbert ? Bitmap.CompressFormat.JPEG : Bitmap.CompressFormat.PNG;
		String fileExtension = isGilbert ? ".jpg" : ".png";
		String mimeType = isGilbert ? "image/jpeg" : "image/png";
		int quality = isGilbert ? JPEG_COMPRESSION_QUALITY : 100; // PNG quality is ignored

		String finalFileName = baseName + fileExtension; // Append correct extension

		String appNameFolder = getString(R.string.app_name);
		if (appNameFolder == null || appNameFolder.trim().isEmpty())
			appNameFolder = "ImageProcessingApp"; // Fallback folder name

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
			imageCollection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
			values.put(MediaStore.Images.Media.RELATIVE_PATH,
					Environment.DIRECTORY_PICTURES + File.separator + appNameFolder);
			values.put(MediaStore.Images.Media.IS_PENDING, 1);
		} else {
			imageCollection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
			File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
					appNameFolder);
			if (!directory.exists() && !directory.mkdirs()) {
				Log.w(TAG, "创建目录失败 (pre-Q) for " + directory.getAbsolutePath());
				// Continue anyway, MediaStore might handle it or save to root Pictures
			}
			// DATA field needs the full path including the filename
			values.put(MediaStore.Images.Media.DATA, new File(directory, finalFileName).getAbsolutePath());
		}
		values.put(MediaStore.Images.Media.DISPLAY_NAME, finalFileName);
		values.put(MediaStore.Images.Media.MIME_TYPE, mimeType);

		Uri imageUri = null;
		OutputStream stream = null;
		boolean success = false;
		try {
			imageUri = resolver.insert(imageCollection, values);
			if (imageUri != null) {
				stream = resolver.openOutputStream(imageUri);
				if (stream != null) {
					bitmapToSave.compress(compressFormat, quality, stream);
					success = true;
				} else {
					Log.e(TAG, "无法打开输出流: " + imageUri);
				}
			} else {
				Log.e(TAG, "MediaStore insert 失败, URI null. Values: " + values.toString());
			}
		} catch (Exception e) {
			Log.e(TAG, "保存图片异常 for " + finalFileName, e);
			success = false;
		} finally {
			if (stream != null)
				try {
					stream.close();
				} catch (IOException ignore) {
				}
			if (imageUri != null) {
				if (success && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
					values.clear();
					values.put(MediaStore.Images.Media.IS_PENDING, 0);
					try {
						resolver.update(imageUri, values, null, null);
					} catch (Exception e) {
						Log.e(TAG, "清 IS_PENDING 失败 for " + finalFileName, e);
						// This is not fatal for the save itself, image is likely saved.
					}
				} else if (!success) { // If save failed, try to delete the incomplete entry
					try {
						resolver.delete(imageUri, null, null);
					} catch (Exception e) {
						Log.e(TAG, "删失败条目错误 for " + finalFileName, e);
					}
					imageUri = null; // Return null if save failed
				}
			}
		}
		return imageUri;
	}

	private Bitmap loadSampledBitmapFromUri(Uri uri, int reqWidth, int reqHeight) {
		if (uri == null)
			return null;
		InputStream inputStream = null;
		try {
			final BitmapFactory.Options options = new BitmapFactory.Options();
			options.inJustDecodeBounds = true;
			inputStream = getContentResolver().openInputStream(uri);
			if (inputStream == null) {
				Log.e(TAG, "无法打开流(p1):" + uri);
				return null;
			}
			BitmapFactory.decodeStream(inputStream, null, options);
			try {
				inputStream.close();
			} catch (IOException ignored) {
			}

			if (options.outWidth <= 0 || options.outHeight <= 0) {
				Log.e(TAG, "无法获取尺寸(p1):" + uri + " (w=" + options.outWidth + ",h=" + options.outHeight + ")");
				String mime = getContentResolver().getType(uri);
				Log.d(TAG, "URI:" + uri + " MIME:" + (mime != null ? mime : "未知"));
				if (mime == null || !mime.startsWith("image/")) {
					mainHandler.post(new Runnable() {
						@Override
						public void run() {
							showBanner(getString(R.string.invalid_image_format_message),true);
						}
					});
				}
				return null;
			}
			//不进行减小分辨率, 除非非常大 (但这里设置了 MAX_LOAD_DIMENSION 实际上没有使用)
			// calculateInSampleSize 会根据 reqWidth/Height 缩小，但这里没用
			options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight); // If reqW/H are MAX_LOAD_DIMENSION, it might sample
			//options.inSampleSize = 1; // To load full resolution before native processing if desired
			options.inJustDecodeBounds = false;
			options.inPreferredConfig = Bitmap.Config.ARGB_8888;

			inputStream = getContentResolver().openInputStream(uri);
			if (inputStream == null) {
				Log.e(TAG, "无法打开流(p2):" + uri);
				return null;
			}
			Bitmap bmp = BitmapFactory.decodeStream(inputStream, null, options);
			if (bmp == null) {
				Log.e(TAG, "decodeStream null (p2):" + uri + " SampleSize: " + options.inSampleSize);
				mainHandler.post(new Runnable() {
					@Override
					public void run() {
						showBanner(getString(R.string.decode_image_failed_message),true);
					}
				});
			}
			return bmp;
		} catch (FileNotFoundException fnfe) {
			Log.e(TAG, "FNF:" + uri, fnfe);
			mainHandler.post(new Runnable() {
				@Override
				public void run() {
					showBanner(getString(R.string.file_not_found_or_accessible_message),true);
				}
			});
			return null;
		} catch (IOException ioe) {
			Log.e(TAG, "加载采样位图 IO 错误:" + uri, ioe);
			return null;
		} catch (SecurityException se) {
			Log.e(TAG, "加载采样位图 安全错误 (权限?):" + uri, se);
			mainHandler.post(new Runnable() {
				@Override
				public void run() {
					showBanner("无法访问图片 (权限问题?)",false);
				}
			});
			return null;
		} catch (Exception e) {
			Log.e(TAG, "加载采样位图一般错误:" + uri, e);
			return null;
		} catch (OutOfMemoryError oom) {
			Log.e(TAG, "加载位图OOM:" + uri + " SampleSize: " + (new BitmapFactory.Options()).inSampleSize, oom); // Re-check options or simplify log
			System.gc(); // Request GC, might help for next attempt elsewhere
			// mainHandler.post(() -> showBanner(getString(R.string.out_of_memory_loading_image)));

			// 修改后的代码 (使用匿名内部类):
			mainHandler.post(new Runnable() {
				@Override
				public void run() {
					showBanner(getString(R.string.out_of_memory_loading_image),true);
				}
			});

			return null;
		} finally {
			if (inputStream != null)
				try {
					inputStream.close();
				} catch (IOException ignore) {
				}
		}
	}
	
		private int calculateInSampleSize(BitmapFactory.Options opt, int reqW, int reqH) {
			if (opt == null || opt.outWidth <= 0 || opt.outHeight <= 0 || reqW <= 0 || reqH <= 0)
				return 1;
			final int h = opt.outHeight, w = opt.outWidth;
			int s = 1;
	    // If EITHER dimension is larger than requested, we might need to sample down.
			if (h > reqH || w > reqW) {
	        // Calculate ratios of height and width to requested height and width
				final int halfH = h / 2;
				final int halfW = w / 2;
	        // Choose the smallest ratio as inSampleSize value, this will guarantee
	        // that both dimensions are greater than or equal to the requested dimensions.
				while ((halfH / s) >= reqH && (halfW / s) >= reqW) {
					s *= 2;
				}
			}
			Log.d(TAG, "计算得到的采样率: " + s + " (请求尺寸: " + reqW + "x" + reqH + ", 原始尺寸: " + w + "x" + h + ")");
			return s;
		}
	
	private void showImageOptionsDialog(final int index) {
		if (!isValidIndex(index)) {
			return;
		}
		final CharSequence[] options = {getString(R.string.option_open), getString(R.string.option_share),
				getString(R.string.save_current_image_option), getString(R.string.option_details),
				getString(R.string.option_remove)};
		new AlertDialog.Builder(this).setTitle(getString(R.string.image_options))
				.setItems(options, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						switch (which) {
							case 0 :
								openImage(index);
								break;
							case 1 :
								shareImage(index);
								break;
							case 2 : // Save current image
								checkWritePermissionAndSaveImage();
								break;
							case 3 :
								showImageDetails(index);
								break;
							case 4 :
								confirmRemoveImageBigImage(index); // Assuming this bypasses a small confirm for big image context
								break;
						}
					}
				}).show();
	}

	// --- MainActivity.java (部分修改) ---

	// ... (import 语句等) ...

	// ... (其他成员变量) ...

	private void appendLog(String message) {
		if (message == null || message.isEmpty())
			return;

		// 在Logcat中仍然打印，这是最佳实践
		Log.d(TAG, "DEBUG_LOG: " + message);

		final String timestamp = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
		final String logEntry = timestamp + ": " + message + "\n";

		mainHandler.post(new Runnable() {
			@Override
			public void run() {
				if (currentLogLines >= MAX_LOG_LINES) {
					int firstNewline = debugLogBuilder.indexOf("\n");
					if (firstNewline != -1) {
						debugLogBuilder.delete(0, firstNewline + 1);
					} else {
						debugLogBuilder.setLength(0);
					}
					currentLogLines--;
				}
				debugLogBuilder.append(logEntry);
				currentLogLines++;
			}
		});
	}

	private void showTemporaryToast(final String message) {
		if (message == null || message.isEmpty())
			return;
		appendLog("TOAST_MSG: " + message);
		mainHandler.post(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
			}
		});
	}

	private File saveBitmapToCacheFile(Bitmap bitmap, String baseName) {
		appendLog("saveBitmapToCacheFile: 开始保存 " + baseName);
		if (bitmap == null || bitmap.isRecycled()) {
			appendLog("saveBitmapToCacheFile ERROR: 输入bitmap为空或已回收");
			return null;
		}
		File imagePath = new File(getCacheDir(), "images_cache");
		if (!imagePath.exists()) {
			if (!imagePath.mkdirs()) {
				appendLog("saveBitmapToCacheFile ERROR: 无法创建目录 " + imagePath.getAbsolutePath());
				return null;
			} else {
				appendLog("saveBitmapToCacheFile: 缓存目录已创建: " + imagePath.getName());
			}
		}
		// For cache, always use PNG to preserve quality for open/share
		File imageFile = new File(imagePath, baseName + ".png");
		appendLog("saveBitmapToCacheFile: 准备保存到: " + imageFile.getName());

		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(imageFile);
			// Share/Open should use PNG to avoid re-compression artifacts if it's already a JPEG
			boolean success = bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
			if (!success) {
				appendLog("saveBitmapToCacheFile ERROR: compress失败 for " + baseName);
				if (imageFile.exists())
					imageFile.delete();
				return null;
			}
			fos.flush();
			appendLog("saveBitmapToCacheFile OK: " + imageFile.getName() + ", 大小: " + imageFile.length() + "B");
			return imageFile;
		} catch (FileNotFoundException fnfe) {
			appendLog("saveBitmapToCacheFile FNF ERROR: "
					+ fnfe.getMessage().substring(0, Math.min(fnfe.getMessage().length(), 50)));
			if (imageFile != null && imageFile.exists())
				imageFile.delete();
			return null;
		} catch (IOException ioe) {
			appendLog("saveBitmapToCacheFile IOE ERROR: "
					+ ioe.getMessage().substring(0, Math.min(ioe.getMessage().length(), 50)));
			if (imageFile != null && imageFile.exists())
				imageFile.delete();
			return null;
		} catch (Exception e) {
			appendLog("saveBitmapToCacheFile EXCEPTION: "
					+ e.getMessage().substring(0, Math.min(e.getMessage().length(), 50)));
			if (imageFile != null && imageFile.exists())
				imageFile.delete();
			return null;
		} finally {
			try {
				if (fos != null) {
					fos.close();
				}
			} catch (IOException e) {
				/* ignore */ }
		}
	}

	private void openImage(final int index) {
		appendLog("openImage: 开始, 索引 " + index);
		if (!isValidIndex(index)) {
			showTemporaryToast(getString(R.string.invalid_index_message));
			appendLog("openImage ERROR: 索引无效");
			return;
		}

		final ImageData imageData = selectedImages.get(index); // Get ImageData
		if (imageData == null) {
			appendLog("openImage ERROR: ImageData is null for index " + index);
			return;
		}

		final Bitmap bmp = imageData.currentBitmap;
		if (bmp == null || bmp.isRecycled()) {
			showTemporaryToast(getString(R.string.image_not_loaded_message));
			appendLog("openImage ERROR: Bitmap为空或已回收");
			return;
		}

		showLoading(true, getString(R.string.preparing_to_open_message));
		executor.execute(new Runnable() {
			@Override
			public void run() {
				appendLog("openImage BG_THREAD: 后台任务开始");
				@SuppressLint("SimpleDateFormat")
				String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
				// Base name for cache file. saveBitmapToCacheFile will add .png
				final File imageFile = saveBitmapToCacheFile(bmp, "OpenableFQT_" + ts + "_" + index);
				appendLog("openImage BG_THREAD: saveBitmapToCacheFile 返回 "
						+ (imageFile != null ? imageFile.getName() : "null"));

				mainHandler.post(new Runnable() {
					@Override
					public void run() {
						appendLog("openImage UI_THREAD: 回调开始");
						showLoading(false, null);
						if (imageFile != null) {
							appendLog("openImage UI_THREAD: 文件有效 " + imageFile.getName() + ", 存在: " + imageFile.exists()
									+ ", 大小: " + imageFile.length());
							if (!imageFile.exists() || imageFile.length() == 0) {
								appendLog("openImage UI_THREAD ERROR: 文件不存在或为空!");
								showTemporaryToast("错误: 无法打开，文件准备失败。");
								return;
							}

							Uri contentUri = null;
							String authority = getApplicationContext().getPackageName() + ".fileprovider";
							appendLog("openImage UI_THREAD: Authority: "
									+ authority.substring(authority.lastIndexOf(".") + 1));

							try {
								contentUri = FileProvider.getUriForFile(MainActivity.this, authority, imageFile);
								appendLog("openImage UI_THREAD: URI生成: " + (contentUri != null
										? "成功 " + contentUri.toString().substring(0,
												Math.min(contentUri.toString().length(), 30)) + "..."
										: "失败"));
							} catch (IllegalArgumentException e) {
								appendLog("openImage UI_THREAD URI_IAE_ERROR: "
										+ e.getMessage().substring(0, Math.min(e.getMessage().length(), 50)) + "...");
								showTemporaryToast("无法生成文件URI进行打开 (参数错误)");
								if (imageFile.exists())
									imageFile.delete(); // Clean up cache
								return;
							} catch (Exception e) {
								appendLog("openImage UI_THREAD URI_EX_ERROR: "
										+ e.getMessage().substring(0, Math.min(e.getMessage().length(), 50)) + "...");
								showTemporaryToast("无法生成文件URI进行打开 (未知错误)");
								if (imageFile.exists())
									imageFile.delete(); // Clean up cache
								return;
							}

							if (contentUri != null) {
								Intent intent = new Intent(Intent.ACTION_VIEW);
								// MIME type for PNG, as saved by saveBitmapToCacheFile
								intent.setDataAndType(contentUri, "image/png");
								intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
								try {
									appendLog("openImage UI_THREAD: 准备启动Activity VIEW");
									startActivity(Intent.createChooser(intent, getString(R.string.open_image_with)));
									appendLog("openImage UI_THREAD: Activity VIEW 已启动(或选择器)");
								} catch (ActivityNotFoundException e) {
									appendLog("openImage UI_THREAD ANFE_ERROR: 无应用处理");
									showTemporaryToast(getString(R.string.cannot_open_file) + " (没有应用可以处理)");
								} catch (Exception e) {
									appendLog("openImage UI_THREAD START_ACTIVITY_EX_ERROR: "
											+ e.getClass().getSimpleName() + ": "
											+ e.getMessage().substring(0, Math.min(e.getMessage().length(), 50)));
									showTemporaryToast(getString(R.string.cannot_open_file));
								}
							} else {
								appendLog("openImage UI_THREAD ERROR: contentUri为空");
								showTemporaryToast(getString(R.string.save_failed,
										getString(R.string.cannot_generate_open_link_suffix)));
								if (imageFile.exists())
									imageFile.delete(); // Clean up cache
							}
						} else {
							appendLog("openImage UI_THREAD ERROR: imageFile为空 (缓存失败)");
							showTemporaryToast(getString(R.string.save_failed,
									getString(R.string.cannot_generate_open_link_suffix)));
						}
						appendLog("openImage UI_THREAD: 回调结束");
					}
				});
				appendLog("openImage BG_THREAD: 后台任务结束");
			}
		});
	}

	private void shareImage(final int index) {
		appendLog("shareImage: 开始, 索引 " + index);
		if (!isValidIndex(index)) {
			showTemporaryToast(getString(R.string.invalid_index_message));
			appendLog("shareImage ERROR: 索引无效");
			return;
		}

		final ImageData imageData = selectedImages.get(index);
		if (imageData == null) {
			appendLog("shareImage ERROR: ImageData is null for index " + index);
			return;
		}
		final Bitmap bmp = imageData.currentBitmap;
		if (bmp == null || bmp.isRecycled()) {
			showTemporaryToast(getString(R.string.image_not_loaded_message));
			appendLog("shareImage ERROR: Bitmap为空或已回收");
			return;
		}

		showLoading(true, getString(R.string.preparing_to_share_message));
		executor.execute(new Runnable() {
			@Override
			public void run() {
				appendLog("shareImage BG_THREAD: 后台任务开始");
				@SuppressLint("SimpleDateFormat")
				String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
				// Base name for cache file. saveBitmapToCacheFile will add .png
				final File imageFile = saveBitmapToCacheFile(bmp, "ShareableFQT_" + ts + "_" + index);
				appendLog("shareImage BG_THREAD: saveBitmapToCacheFile 返回 "
						+ (imageFile != null ? imageFile.getName() : "null"));

				mainHandler.post(new Runnable() {
					@Override
					public void run() {
						appendLog("shareImage UI_THREAD: 回调开始");
						showLoading(false, null);
						if (imageFile != null) {
							appendLog("shareImage UI_THREAD: 文件有效 " + imageFile.getName() + ", 存在: "
									+ imageFile.exists() + ", 大小: " + imageFile.length());
							if (!imageFile.exists() || imageFile.length() == 0) {
								appendLog("shareImage UI_THREAD ERROR: 文件不存在或为空!");
								showTemporaryToast("错误: 无法分享，文件准备失败。");
								return;
							}

							Uri contentUri = null;
							String authority = getApplicationContext().getPackageName() + ".fileprovider";
							appendLog("shareImage UI_THREAD: Authority: "
									+ authority.substring(authority.lastIndexOf(".") + 1));

							try {
								contentUri = FileProvider.getUriForFile(MainActivity.this, authority, imageFile);
								appendLog("shareImage UI_THREAD: URI生成: " + (contentUri != null
										? "成功 " + contentUri.toString().substring(0,
												Math.min(contentUri.toString().length(), 30)) + "..."
										: "失败"));
							} catch (IllegalArgumentException e) {
								appendLog("shareImage UI_THREAD URI_IAE_ERROR: "
										+ e.getMessage().substring(0, Math.min(e.getMessage().length(), 50)) + "...");
								showTemporaryToast("无法生成文件URI进行分享 (参数错误)");
								if (imageFile.exists())
									imageFile.delete();
								return;
							} catch (Exception e) {
								appendLog("shareImage UI_THREAD URI_EX_ERROR: "
										+ e.getMessage().substring(0, Math.min(e.getMessage().length(), 50)) + "...");
								showTemporaryToast("无法生成文件URI进行分享 (未知错误)");
								if (imageFile.exists())
									imageFile.delete();
								return;
							}

							if (contentUri != null) {
								Intent shareIntent = new Intent(Intent.ACTION_SEND);
								// MIME type for PNG as saved by saveBitmapToCacheFile
								shareIntent.setType("image/png");
								shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
								shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
								if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP) { // Grant URI for older Androids
									appendLog("shareImage UI_THREAD: 旧版安卓，授予权限中...");
									List<ResolveInfo> resInfoList = getPackageManager()
											.queryIntentActivities(shareIntent, PackageManager.MATCH_DEFAULT_ONLY);
									for (ResolveInfo resolveInfo : resInfoList) {
										String packageName = resolveInfo.activityInfo.packageName;
										grantUriPermission(packageName, contentUri,
												Intent.FLAG_GRANT_READ_URI_PERMISSION);
									}
									appendLog("shareImage UI_THREAD: 旧版权限授予完成");
								}
								try {
									appendLog("shareImage UI_THREAD: 准备启动Activity SEND");
									startActivity(
											Intent.createChooser(shareIntent, getString(R.string.share_image_via)));
									appendLog("shareImage UI_THREAD: Activity SEND 已启动(或选择器)");
								} catch (ActivityNotFoundException e) {
									appendLog("shareImage UI_THREAD ANFE_ERROR: 无应用处理");
									showTemporaryToast(getString(R.string.cannot_share_file) + " (没有应用可以处理)");
								} catch (Exception e) {
									appendLog("shareImage UI_THREAD START_ACTIVITY_EX_ERROR: "
											+ e.getClass().getSimpleName() + ": "
											+ e.getMessage().substring(0, Math.min(e.getMessage().length(), 50)));
									showTemporaryToast(getString(R.string.cannot_share_file));
								}
							} else {
								appendLog("shareImage UI_THREAD ERROR: contentUri为空");
								showTemporaryToast(getString(R.string.save_failed,
										getString(R.string.cannot_generate_share_link_suffix)));
								if (imageFile.exists())
									imageFile.delete();
							}
						} else {
							appendLog("shareImage UI_THREAD ERROR: imageFile为空 (缓存失败)");
							showTemporaryToast(getString(R.string.save_failed,
									getString(R.string.cannot_generate_share_link_suffix)));
						}
						appendLog("shareImage UI_THREAD: 回调结束");
					}
				});
				appendLog("shareImage BG_THREAD: 后台任务结束");
			}
		});
	}

	private void showImageDetails(int index) {
		if (selectedImages == null || !isValidIndex(index)) {
			Log.w(TAG, "showImageDetails: Invalid index or selectedImages is null. Index: " + index);
			return;
		}
		ImageData data = selectedImages.get(index);
		if (data == null) {
			Log.w(TAG, "showImageDetails: ImageData at index " + index + " is null.");
			return;
		}

		StringBuilder details = new StringBuilder();
		String displayName = null;
		long fileSizeInBytes = -1;

		if (data.originalUri != null) {
			Cursor cursor = null;
			try {
				cursor = getContentResolver().query(data.originalUri, null, null, null, null);
				if (cursor != null && cursor.moveToFirst()) {
					int displayNameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
					if (displayNameIndex != -1) {
						displayName = cursor.getString(displayNameIndex);
					}
					int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
					if (sizeIndex != -1 && !cursor.isNull(sizeIndex)) {
						fileSizeInBytes = cursor.getLong(sizeIndex);
					}
				}
			} catch (Exception e) {
				Log.e(TAG, "Error querying URI metadata for details", e);
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}

			if (fileSizeInBytes < 0 && "file".equalsIgnoreCase(data.originalUri.getScheme())) {
				String path = data.originalUri.getPath();
				if (path != null) {
					File file = new File(path);
					if (file.exists() && file.isFile()) {
						fileSizeInBytes = file.length();
						if (displayName == null) {
							displayName = file.getName();
						}
					}
				}
			}
			if (displayName == null && data.originalUri.getLastPathSegment() != null) {
				displayName = data.originalUri.getLastPathSegment();
			}
		}

		if (displayName != null && !displayName.isEmpty()) {
			details.append(getString(R.string.details_file_name_label)).append(" ").append(displayName);
		} else if (data.originalUri != null) {
			details.append(getString(R.string.details_uri, data.originalUri.toString()));
		} else {
			details.append(getString(R.string.uri_unknown_label));
		}

		details.append("\n").append(getString(R.string.dimensions_label)).append(" ");
		if (data.currentBitmap != null && !data.currentBitmap.isRecycled()) {
			details.append(data.currentBitmap.getWidth()).append("x").append(data.currentBitmap.getHeight());
		} else { // Try to get original dimensions if current not available
			BitmapFactory.Options options = new BitmapFactory.Options();
			options.inJustDecodeBounds = true;
			InputStream inputStream = null;
			try {
				if (data.originalUri != null) {
					inputStream = getContentResolver().openInputStream(data.originalUri);
					if (inputStream != null) {
						BitmapFactory.decodeStream(inputStream, null, options);
						if (options.outWidth > 0 && options.outHeight > 0) {
							details.append(options.outWidth).append("x").append(options.outHeight).append(" (")
									.append(getString(R.string.details_original_dims)).append(")");
						} else {
							details.append(getString(R.string.details_not_loaded));
						}
					} else {
						details.append(getString(R.string.details_not_loaded));
					}
				} else {
					details.append(getString(R.string.details_not_loaded));
				}
			} catch (Exception e) {
				Log.e(TAG, "Error getting original dimensions from URI for details", e);
				details.append(getString(R.string.details_not_loaded));
			} finally {
				if (inputStream != null) {
					try {
						inputStream.close();
					} catch (IOException e) {
						/* ignore */ }
				}
			}
		}

		if (fileSizeInBytes >= 0) {
			details.append("\n").append(getString(R.string.dimensions_size, FileUtils.formatFileSize(fileSizeInBytes)));
		} else {
			details.append("\n").append(getString(R.string.dimensions_size_unknown));
		}

		new AlertDialog.Builder(this).setTitle(R.string.image_details).setMessage(details.toString())
				.setPositiveButton(R.string.yes, null) // "OK" button
				.show();
	}

	private boolean isValidIndex(int i) {
		return i >= 0 && i < selectedImages.size();
	}

	private void safeRecycle(Bitmap b) {
		if (b != null && !b.isRecycled()) {
			Log.d(TAG, "安全回收 bitmap (hashCode): " + b.hashCode() + " WxH: " + b.getWidth() + "x" + b.getHeight()
					+ " isRecycledBefore: " + b.isRecycled());
			b.recycle();
			Log.d(TAG, "安全回收 bitmap (hashCode): " + b.hashCode() + " isRecycledAfter: " + b.isRecycled());
		}
	}

	private void updateUiVisibility() {
		final boolean hasImg = !selectedImages.isEmpty();
		mainHandler.post(new Runnable() {
			@Override
			public void run() {
				if (initialAddButton != null)
					initialAddButton.setVisibility(hasImg ? View.GONE : View.VISIBLE);
				if (thumbnailScrollView != null)
					thumbnailScrollView.setVisibility(hasImg ? View.VISIBLE : View.GONE);
				if (bottomActionLayout != null || batchActionLayout != null)
					bottomActionLayout.setVisibility(hasImg ? View.VISIBLE : View.GONE);
				batchActionLayout.setVisibility(hasImg ? View.VISIBLE : View.GONE);
				if (controlsLayout != null)
					controlsLayout.setVisibility(hasImg ? View.VISIBLE : View.GONE);
				updateButtonStates(); // Call this to enable/disable buttons based on new state
			}
		});
	}

	private void updateStatusText() {
		final String s = selectedImages.isEmpty()
				? getString(R.string.please_select_image)
				: getString(R.string.selected_n_images, selectedImages.size());
		mainHandler.post(new Runnable() {
			@Override
			public void run() {
				if (statusTextView != null)
					statusTextView.setText(s);
			}
		});
	}

	private void updateInfoText(final Bitmap b, final long durMs) {
		final String s;
		if (b != null && !b.isRecycled()) {
			if (durMs >= 0) // Duration provided
				s = getString(R.string.info_format, b.getWidth(), b.getHeight(), durMs);
			else // No duration, just resolution
				s = getString(R.string.info_resolution_only, b.getWidth(), b.getHeight());
		} else { // No valid bitmap
			s = getString(R.string.placeholder_info);
		}
		mainHandler.post(new Runnable() {
			@Override
			public void run() {
				if (infoTextView != null)
					infoTextView.setText(s);
			}
		});
	}

	private void updateButtonStates() {
		mainHandler.post(new Runnable() {
			@Override
			public void run() {
				boolean isLoading = (progressBar != null && progressBar.getVisibility() == View.VISIBLE);
				boolean enableButtons = !isLoading; // Disable all if loading
				boolean hasImages = !selectedImages.isEmpty();
				boolean currentImageValid = false;
				if (isValidIndex(currentlyDisplayedIndex)) {
					ImageData currentData = selectedImages.get(currentlyDisplayedIndex);
					if (currentData != null && currentData.currentBitmap != null
							&& !currentData.currentBitmap.isRecycled()) {
						currentImageValid = true;
					}
				}

				if (initialAddButton != null)
					initialAddButton.setEnabled(enableButtons && !hasImages); // Only if no images and not loading
				if (btnObfuscate != null)
					btnObfuscate.setEnabled(enableButtons && currentImageValid);
				if (btnDeobfuscate != null)
					btnDeobfuscate.setEnabled(enableButtons && currentImageValid);
				if (btnRevert != null)
					btnRevert.setEnabled(enableButtons && hasImages); // Needs images, not necessarily current valid one
				if (btnClear != null)
					btnClear.setEnabled(enableButtons && hasImages); // Needs images
				if (btnSave != null)
					btnSave.setEnabled(enableButtons && currentImageValid); // Needs a valid current image

				if (btnBatchObfuscate != null)
					btnObfuscate.setEnabled(enableButtons && currentImageValid);
				if (btnBatchDeobfuscate != null)
					btnDeobfuscate.setEnabled(enableButtons && currentImageValid);
				if (btnBatchRevert != null)
					btnRevert.setEnabled(enableButtons && hasImages); // Needs images, not necessarily current valid one
				if (btnBatchClear != null)
					btnClear.setEnabled(enableButtons && hasImages); // Needs images
				if (btnBatchSave != null)
					btnSave.setEnabled(enableButtons && currentImageValid); // Needs a valid current image

			}
		});
	}

	private void showLoading(final boolean show, final String msg) {
		mainHandler.post(new Runnable() {
			@Override
			public void run() {
				if (progressBar == null)
					return;
				progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
				updateButtonStates(); // Critical to disable buttons while loading
				if (show && msg != null && statusTextView != null) {
					statusTextView.setText(msg);
				} else if (!show) { // When hiding progress, restore status text
					updateStatusText();
				}
			}
		});
	}

	private void showToast(final String msg) {
		if (msg == null || msg.isEmpty())
			return;
		mainHandler.post(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
		if (requestCode == PERMISSION_REQUEST_READ_STORAGE) {
			if (granted)
				pickImage();
			else
				showBanner(getString(R.string.read_permission_denied),false);
		} else if (requestCode == PERMISSION_REQUEST_WRITE_STORAGE) {
			if (granted) // User might retry saving now
				showBanner(getString(R.string.write_permission_granted_retry_message),false);
			else
				showBanner(getString(R.string.write_permission_denied),true);
		}
		updateButtonStates(); // Re-evaluate button states after permission dialog
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuItem item = null;
		String aboutText = getString(R.string.about); // Default
		try {
			aboutText = getMenuItemAboutText(); // Try native
		} catch (UnsatisfiedLinkError e) {
			Log.w(TAG, "Failed to get about menu text from native", e);
		}
		item = menu.add(Menu.NONE, MENU_ITEM_ABOUT_ID, Menu.NONE, aboutText);
		if (item != null)
		  
			item.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
			
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == MENU_ITEM_ABOUT_ID) {
			String title = getString(R.string.about);
			String message = getString(R.string.app_name) + "\n(" + getString(R.string.load_details_failed_suffix)
					+ ")";
			String buttonText = getString(R.string.yes); // "OK"
			try {
				title = getDialogTitle();
				message = getDialogMessage();
				buttonText = getDialogButtonText();
				
			} catch (UnsatisfiedLinkError e) {
				Log.w(TAG, "Failed to get about dialog details from native", e);
			}
			
		  SpannableString spannableMessage = new SpannableString(message);

		  // 设置较小的字号 (例如，原始字号的 0.8 倍)
		  // RelativeSizeSpan(0.8f) 表示原始大小的80%
		  // AbsoluteSizeSpan(12, true) 表示 12sp (true 表示单位是 sp)
		  // 你可以选择适合你的方式
		  spannableMessage.setSpan(new RelativeSizeSpan(0.8f), 0, message.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
			
			new AlertDialog.Builder(this).setTitle(title).setMessage(spannableMessage).setPositiveButton(buttonText, null)
					.show();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy: Shutting down executor and cleaning up.");
		if (executor != null && !executor.isShutdown()) {
			executor.shutdown();
			try {
				if (!executor.awaitTermination(2, TimeUnit.SECONDS)) {
					executor.shutdownNow();
					if (!executor.awaitTermination(2, TimeUnit.SECONDS)) {
						Log.e(TAG, "线程池未能终止");
					}
				}
			} catch (InterruptedException ie) {
				executor.shutdownNow();
				Thread.currentThread().interrupt();
				Log.e(TAG, "线程池终止被中断", ie);
			}
		}
		if (mainHandler != null)
			mainHandler.removeCallbacksAndMessages(null); // Clear pending posts

		clearAllImages(); // Recycle all bitmaps and clear list
		cleanupTemporaryFiles(); // Clean cache
		Log.d(TAG, "onDestroy: Cleanup complete.");
	}

	private void cleanupTemporaryFiles() {
		File imageDir = new File(getCacheDir(), "images_cache");
		if (imageDir.exists() && imageDir.isDirectory()) {
			File[] files = imageDir.listFiles();
			if (files != null) {
				for (File file : files) {
					// Check for prefixes used in saveBitmapToCacheFile
					if (file.getName().startsWith("ShareableFQT_") || file.getName().startsWith("OpenableFQT_")) {
						if (file.delete()) {
							Log.d(TAG, "已删除临时文件: " + file.getAbsolutePath());
						} else {
							Log.w(TAG, "删除临时文件失败: " + file.getAbsolutePath());
						}
					}
				}
			}
		}
	}
	// Dummy FileUtils for showImageDetails - replace with your actual implementation or remove if not used
	// This is just to make the provided code compile if you have a FileUtils.formatFileSize
	public static class FileUtils {
		public static String formatFileSize(long size) {
			if (size <= 0)
				return "0 B";
			final String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
			int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
			return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
		}
	}
}

